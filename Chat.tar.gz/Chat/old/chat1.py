import sys
import os
import subprocess
from datetime import datetime
import platform
from pathlib import Path
import mimetypes
import chardet
import re
import tempfile
import wave
import pyaudio
import speech_recognition as sr
from gtts import gTTS
import pygame

from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                              QHBoxLayout, QTextEdit, QLineEdit, QPushButton,
                              QLabel, QComboBox, QMessageBox, QInputDialog,
                              QSlider, QColorDialog, QMenu, QSplitter, QWidgetAction,
                              QDialog, QFileDialog, QScrollArea, QFrame)
from PySide6.QtCore import Qt, QThread, Signal, Slot, QSettings, QUrl, QRegularExpression, QTimer
from PySide6.QtGui import (QPalette, QColor, QTextCursor, QActionGroup, QAction,
                          QFont, QTextCharFormat, QSyntaxHighlighter, QTextDocument,
                          QTextFormat, QGuiApplication, QClipboard, QIcon)
from PySide6.QtMultimedia import QSoundEffect

# --- Вспомогательные классы ---

class VoiceWorker(QThread):
    """Распознавание речи и синтез голоса"""
    speech_recognized = Signal(str)
    error_occurred = Signal(str)
    voice_playing = Signal(bool)

    def __init__(self, mode="recognize", text=None, parent=None):
        super().__init__(parent)
        self.mode = mode  # "recognize" или "synthesize"
        self.text = text
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # Инициализация pygame для воспроизведения звука
        pygame.mixer.init()

    def run(self):
        try:
            if self.mode == "recognize":
                self.recognize_speech()
            elif self.mode == "synthesize":
                self.synthesize_speech(self.text) # <<< ИСПРАВЛЕНО
        except Exception as e:
            self.error_occurred.emit(f"Ошибка голосового модуля: {str(e)}")

    def recognize_speech(self):
        """Распознавание речи с микрофона"""
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source)
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=10)

            text = self.recognizer.recognize_google(audio, language="ru-RU")
            self.speech_recognized.emit(text)

        except sr.WaitTimeoutError:
            self.error_occurred.emit("Таймаут: речь не обнаружена")
        except sr.UnknownValueError:
            self.error_occurred.emit("Речь не распознана")
        except sr.RequestError as e:
            self.error_occurred.emit(f"Ошибка сервиса распознавания: {e}")

    def synthesize_speech(self, text):
        """Синтез речи из текста"""
        try:
            # Создаем временный файл для аудио
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
                tts = gTTS(text=text, lang='ru', slow=False)
                tts.save(tmp_file.name)
                tmp_file_path = tmp_file.name

            # Воспроизводим аудио
            self.voice_playing.emit(True)
            pygame.mixer.music.load(tmp_file_path)
            pygame.mixer.music.play()

            # Ждем завершения воспроизведения
            while pygame.mixer.music.get_busy():
                QThread.msleep(100)

            self.voice_playing.emit(False)

            # Удаляем временный файл
            os.unlink(tmp_file_path)

        except Exception as e:
            self.error_occurred.emit(f"Ошибка синтеза речи: {str(e)}")
            self.voice_playing.emit(False)

class CodeHighlighter(QSyntaxHighlighter):
    """Подсветка синтаксиса для различных языков программирования"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []

        # Базовые правила для разных языков
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Bold)

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))

        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8"))

        # Общие ключевые слова для нескольких языков
        keywords = [
            'break', 'case', 'catch', 'class', 'const', 'continue', 'default',
            'delete', 'do', 'else', 'enum', 'export', 'extends', 'false', 'finally',
            'for', 'function', 'if', 'import', 'in', 'instanceof', 'new', 'null',
            'return', 'super', 'switch', 'this', 'throw', 'true', 'try', 'typeof',
            'var', 'void', 'while', 'with', 'yield'
        ]

        for keyword in keywords:
            pattern = r'\b' + keyword + r'\b'
            self.highlighting_rules.append((QRegularExpression(pattern), keyword_format))

        # Строки
        self.highlighting_rules.append((QRegularExpression(r'\".*?\"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'\'.*?\''), string_format))

        # Комментарии
        self.highlighting_rules.append((QRegularExpression(r'//.*'), comment_format))
        self.highlighting_rules.append((QRegularExpression(r'/\*.*?\*/'), comment_format))

        # Числа
        self.highlighting_rules.append((QRegularExpression(r'\b\d+\b'), number_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

class FileAttachmentWidget(QFrame):
    """Виджет для отображения прикрепленного файла"""
    def __init__(self, file_path, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.setFrameStyle(QFrame.Box)
        self.setStyleSheet("""
            QFrame {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px;
                margin: 2px;
            }
        """)

        layout = QVBoxLayout(self)

        file_name = QLabel(Path(file_path).name)
        file_name.setStyleSheet("font-weight: bold;")

        file_info = QLabel(f"{self.get_file_size()} | {self.get_file_type()}")
        file_info.setStyleSheet("color: #666; font-size: 10px;")

        btn_layout = QHBoxLayout()
        view_btn = QPushButton("Просмотр")
        view_btn.clicked.connect(self.view_file)
        view_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        copy_btn = QPushButton("Копировать")
        copy_btn.clicked.connect(self.copy_content)
        copy_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        remove_btn = QPushButton("✕")
        remove_btn.clicked.connect(self.remove_file)
        remove_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")
        remove_btn.setFixedSize(20, 20)

        btn_layout.addWidget(view_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(remove_btn)

        layout.addWidget(file_name)
        layout.addWidget(file_info)
        layout.addLayout(btn_layout)

        self.setFixedHeight(80)

    def get_file_size(self):
        size = os.path.getsize(self.file_path)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"

    def get_file_type(self):
        mime_type, _ = mimetypes.guess_type(self.file_path)
        if mime_type:
            return mime_type.split('/')[-1].upper()
        return Path(self.file_path).suffix.upper().replace('.', '')

    def view_file(self):
        """Просмотр содержимого файла"""
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Просмотр: {Path(self.file_path).name}")
        dialog.setMinimumSize(800, 600)

        layout = QVBoxLayout(dialog)

        # Текстовое поле для содержимого
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)

        # Загружаем содержимое файла
        try:
            content = self.read_file_content()
            text_edit.setPlainText(content)

            # Включаем подсветку синтаксиса для известных форматов
            if self.is_code_file():
                highlighter = CodeHighlighter(text_edit.document())

        except Exception as e:
            text_edit.setPlainText(f"Ошибка чтения файла: {str(e)}")

        layout.addWidget(text_edit)

        # Кнопки
        btn_layout = QHBoxLayout()
        copy_btn = QPushButton("Копировать всё")
        copy_btn.clicked.connect(lambda: self.copy_to_clipboard(content))
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(dialog.accept)

        btn_layout.addWidget(copy_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)

        layout.addLayout(btn_layout)
        dialog.exec()

    def read_file_content(self):
        """Чтение содержимого файла с определением кодировки"""
        try:
            # Определяем кодировку
            with open(self.file_path, 'rb') as f:
                raw_data = f.read()
                result = chardet.detect(raw_data)
                encoding = result['encoding'] or 'utf-8'

            # Читаем файл в правильной кодировке
            with open(self.file_path, 'r', encoding=encoding, errors='replace') as f:
                return f.read()
        except UnicodeDecodeError:
            # Если не удается декодировать как текст, показываем бинарные данные
            return "Бинарный файл - содержимое не может быть отображено как текст"

    def is_code_file(self):
        """Проверяем, является ли файл кодом"""
        code_extensions = {'.py', '.js', '.java', '.cpp', '.c', '.h', '.html',
                          '.css', '.php', '.rb', '.go', '.rs', '.ts', '.json',
                          '.xml', '.yaml', '.yml', '.sql', '.sh', '.bat', '.ps1'}
        return Path(self.file_path).suffix.lower() in code_extensions

    def copy_content(self):
        """Копирование содержимого файла в буфер обмена"""
        try:
            content = self.read_file_content()
            self.copy_to_clipboard(content)
            QMessageBox.information(self, "Успех", "Содержимое файла скопировано в буфер обмена")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось скопировать файл: {str(e)}")

    def copy_to_clipboard(self, text):
        """Копирование текста в буфер обмена"""
        clipboard = QGuiApplication.clipboard()
        clipboard.setText(text)

    def remove_file(self):
        """Удаление прикрепленного файла"""
        self.deleteLater()

class OllamaWorker(QThread):
    """Отвечает за асинхронный запуск модели Ollama."""
    response_received = Signal(str)
    error_occurred = Signal(str)
    finished_signal = Signal()

    def __init__(self, model_name, prompt, attachments=None):
        super().__init__()
        self.model_name = model_name
        self.prompt = prompt
        self.attachments = attachments or []

    def run(self):
        try:
            # Подготавливаем полный промпт с вложениями
            full_prompt = self.prompt

            if self.attachments:
                full_prompt += "\n\n--- ПРИКРЕПЛЕННЫЕ ФАЙЛЫ ---\n"
                for i, attachment in enumerate(self.attachments, 1):
                    try:
                        content = self.read_file_content(attachment)
                        file_name = Path(attachment).name
                        file_extension = Path(attachment).suffix.lower()

                        full_prompt += f"\n--- ФАЙЛ {i}: {file_name} ---\n"
                        full_prompt += f"Расширение: {file_extension}\n"
                        full_prompt += f"Содержимое:\n```{file_extension}\n{content}\n```\n"

                    except Exception as e:
                        full_prompt += f"\n--- ФАЙЛ {i}: {Path(attachment).name} ---\n"
                        full_prompt += f"ОШИБКА ЧТЕНИЯ: {str(e)}\n"

                full_prompt += "\n--- КОНЕЦ ФАЙЛОВ ---\n\n"
                full_prompt += "Проанализируй прикрепленные файлы и ответь на мой запрос с учетом их содержимого.\n"

            print("Отправляемый промпт в Ollama:")
            print("=" * 50)
            print(full_prompt)
            print("=" * 50)

            # Используем subprocess.Popen для потоковой обработки
            cmd = ["ollama", "run", self.model_name]

            creation_flags = subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0

            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True,
                creationflags=creation_flags
            )

            # Отправляем промпт и закрываем stdin
            process.stdin.write(full_prompt)
            process.stdin.close()

            # Читаем вывод построчно
            for line in process.stdout:
                if line.strip():
                    self.response_received.emit(line)

            # Ждем завершения процесса
            process.wait()

            if process.returncode != 0:
                error_msg = process.stderr.read() if process.stderr else "Неизвестная ошибка"
                self.error_occurred.emit(f"Ошибка модели (код {process.returncode}): {error_msg}")

            self.finished_signal.emit()

        except subprocess.TimeoutExpired:
            self.error_occurred.emit("Таймаут: модель не ответила в течение 5 минут")
            self.finished_signal.emit()
        except Exception as e:
            self.error_occurred.emit(f"Ошибка запуска процесса: {str(e)}")
            self.finished_signal.emit()

    def read_file_content(self, file_path):
        """Чтение содержимого файла с обработкой различных кодировок"""
        try:
            # Сначала пробуем прочитать как текст с определением кодировки
            with open(file_path, 'rb') as f:
                raw_data = f.read()

            # Определяем кодировку
            result = chardet.detect(raw_data)
            encoding = result['encoding'] or 'utf-8'
            confidence = result.get('confidence', 0)

            # Пробуем прочитать с определенной кодировкой
            try:
                content = raw_data.decode(encoding, errors='replace')

                # Если файл слишком большой, обрезаем его
                max_file_size = 10000  # 10k символов максимум
                if len(content) > max_file_size:
                    content = content[:max_file_size] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"

                return content

            except UnicodeDecodeError:
                # Если не удалось декодировать, пробуем другие кодировки
                for alt_encoding in ['utf-8', 'latin-1', 'cp1251', 'cp1252']:
                    try:
                        content = raw_data.decode(alt_encoding, errors='replace')
                        if len(content) > 10000:
                            content = content[:10000] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"
                        return content
                    except UnicodeDecodeError:
                        continue

                # Если все кодировки не подошли, возвращаем как бинарный
                return f"БИНАРНЫЙ ФАЙЛ. Размер: {len(raw_data)} байт. Не может быть прочитан как текст."

        except Exception as e:
            return f"ОШИБКА ЧТЕНИЯ ФАЙЛА: {str(e)}"

class ModelManager:
    """Управляет списком доступных моделей Ollama."""
    def load_models(self):
        models = []
        try:
            creation_flags = subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True,
                text=True,
                timeout=10,
                creationflags=creation_flags
            )
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    for line in lines[1:]:
                        parts = line.split()
                        if parts:
                            models.append(parts[0])
        except Exception as e:
            print(f"Ошибка загрузки моделей: {e}")
        return models

class SoundManager:
    """Управляет звуковыми уведомлениями."""
    def __init__(self):
        self.enabled = True
        self.sound_effect = QSoundEffect()
        sound_path = Path("notification.wav")
        if sound_path.exists():
            self.sound_effect.setSource(QUrl.fromLocalFile(str(sound_path)))
        else:
            print(f"Файл звука не найден: {sound_path}")

    def set_enabled(self, enabled):
        """Установить состояние звука"""
        self.enabled = enabled

    def play_notification(self):
        if self.enabled and self.sound_effect.source().isValid():
            self.sound_effect.play()

class ThemeManager:
    """
    Управляет темами (светлая, темная, кастомная) и генерирует стили.
    """
    def __init__(self):
        self.themes = {
            "Темная": {
                "background": "#1e1e2e", "text": "#cdd6f4", "base": "#181825",
                "accent": "#89b4fa", "user_message": "#a6e3a1", "ai_message": "#89dceb",
                "system_message": "#f38ba8", "border": "#45475a",
                "button": "#585b70", "button_text": "#cdd6f4"
            },
            "Светлая": {
                "background": "#eff1f5", "text": "#4c4f69", "base": "#ffffff",
                "accent": "#1e66f5", "user_message": "#40a02b", "ai_message": "#04a5e5",
                "system_message": "#d20f39", "border": "#dce0e8",
                "button": "#dce0e8", "button_text": "#4c4f69"
            }
        }
        self.custom_colors = {}

    def get_palette_and_style(self, theme_name, background_opacity=100):
        colors = self.themes.get(theme_name, {})
        if theme_name == "Пользовательская":
            base_theme = self.themes["Темная"]
            colors = {**base_theme, **self.custom_colors}

        if not colors:
            return QPalette(), "", {}

        bg_color = QColor(colors["background"])
        base_color = QColor(colors["base"])

        if background_opacity < 100:
            bg_alpha = int(255 * (background_opacity / 100.0))
            base_alpha = int(255 * min(1.0, (background_opacity / 100.0) + 0.2))

            bg_color.setAlpha(bg_alpha)
            base_color.setAlpha(base_alpha)

        palette = QPalette()
        palette.setColor(QPalette.Window, bg_color)
        palette.setColor(QPalette.WindowText, QColor(colors["text"]))
        palette.setColor(QPalette.Base, base_color)
        palette.setColor(QPalette.AlternateBase, QColor(colors["border"]))
        palette.setColor(QPalette.Text, QColor(colors["text"]))
        palette.setColor(QPalette.Button, QColor(colors["button"]))
        palette.setColor(QPalette.ButtonText, QColor(colors["button_text"]))
        palette.setColor(QPalette.Highlight, QColor(colors["accent"]))
        palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))

        bg_rgba = f"rgba({bg_color.red()}, {bg_color.green()}, {bg_color.blue()}, {bg_color.alpha()})"
        base_rgba = f"rgba({base_color.red()}, {base_color.green()}, {base_color.blue()}, {base_color.alpha()})"

        stylesheet = f"""
            QMainWindow {{
                background-color: transparent;
                border: none;
            }}
            QWidget#centralWidget {{
                background-color: {bg_rgba};
                border-radius: 12px;
                border: 1px solid {colors["border"]};
            }}
            QTextEdit, QLineEdit, QComboBox {{
                background-color: {base_rgba};
                color: {colors["text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 10px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 10pt;
            }}
            QPushButton {{
                background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {colors['button']},
                    stop:1 {QColor(colors['button']).darker(110).name()}
                );
                color: {colors["button_text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {colors["accent"]};
                color: #ffffff;
                border: 1px solid {colors["accent"]};
            }}
            QSplitter::handle {{
                background-color: {colors["border"]};
            }}
            QSplitter::handle:horizontal {{ width: 1px; }}
            QMenu {{
                background-color: {base_rgba};
                border: 1px solid {colors["border"]};
                color: {colors["text"]};
            }}
            QMenu::item:selected {{
                background-color: {colors["accent"]};
                color: #ffffff;
            }}
            *:focus {{
                border: 1px solid {colors["accent"]};
            }}
        """
        return palette, stylesheet, colors

class ChatWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.theme_manager = ThemeManager()
        self.model_manager = ModelManager()
        self.sound_manager = SoundManager()
        self.settings = QSettings("AI-Chat", "OllamaClientRefactored")

        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.current_ai_response = ""
        self.drag_pos = None
        self.background_opacity = 100
        self.attachments = []
        self.is_listening = False
        self.is_speaking = False

        self.init_ui()
        self.load_settings()

    def init_ui(self):
        """Компактный интерфейс с разделением истории"""
        self.setWindowTitle("AI Chat")
        self.setGeometry(100, 100, 1200, 800)

        self.central_widget = QWidget()
        self.central_widget.setObjectName("centralWidget")
        self.setCentralWidget(self.central_widget)

        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(10)

        # --- Верхняя панель управления ---
        top_bar_layout = QHBoxLayout()
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(35)
        self.refresh_models()
        refresh_btn = QPushButton("Обновить")
        refresh_btn.clicked.connect(self.refresh_models)
        download_btn = QPushButton("Загрузить модель")
        download_btn.clicked.connect(self.download_model)

        # Кнопки управления окном
        minimize_btn = QPushButton("—")
        minimize_btn.setFixedSize(30, 30)
        minimize_btn.clicked.connect(self.showMinimized)
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.clicked.connect(self.close)

        top_bar_layout.addWidget(QLabel("Модель:"))
        top_bar_layout.addWidget(self.model_combo, 1)
        top_bar_layout.addWidget(refresh_btn)
        top_bar_layout.addWidget(download_btn)
        top_bar_layout.addStretch()
        top_bar_layout.addWidget(minimize_btn)
        top_bar_layout.addWidget(close_btn)

        # --- Область прикрепленных файлов ---
        self.attachments_scroll = QScrollArea()
        self.attachments_scroll.setMaximumHeight(100)
        self.attachments_scroll.setWidgetResizable(True)
        self.attachments_widget = QWidget()
        self.attachments_layout = QHBoxLayout(self.attachments_widget)
        self.attachments_layout.setContentsMargins(5, 5, 5, 5)
        self.attachments_scroll.setWidget(self.attachments_widget)
        self.attachments_scroll.setVisible(False)

        # --- Разделенная область чатов ---
        chat_splitter = QSplitter(Qt.Horizontal)

        user_widget = QWidget()
        user_layout = QVBoxLayout(user_widget)
        user_layout.setContentsMargins(0, 0, 0, 0)
        user_label = QLabel("Ваши сообщения")
        user_label.setAlignment(Qt.AlignCenter)
        user_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.user_chat_history = QTextEdit()
        self.user_chat_history.setReadOnly(True)
        self.user_chat_history.setPlaceholderText("Введите сообщение...")
        user_layout.addWidget(user_label)
        user_layout.addWidget(self.user_chat_history)

        ai_widget = QWidget()
        ai_layout = QVBoxLayout(ai_widget)
        ai_layout.setContentsMargins(0, 0, 0, 0)
        ai_label = QLabel("Ответы модели")
        ai_label.setAlignment(Qt.AlignCenter)
        ai_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.ai_chat_history = QTextEdit()
        self.ai_chat_history.setReadOnly(True)
        self.ai_chat_history.setPlaceholderText("Здесь появятся ответы...")
        ai_layout.addWidget(ai_label)
        ai_layout.addWidget(self.ai_chat_history)

        chat_splitter.addWidget(user_widget)
        chat_splitter.addWidget(ai_widget)
        chat_splitter.setSizes([self.width() // 2, self.width() // 2])

        # --- Поле ввода и кнопки ---
        input_layout = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Введите ваше сообщение...")
        self.input_field.returnPressed.connect(self.send_message)
        self.input_field.setMinimumHeight(40)

        # Кнопка прикрепления файлов
        attach_btn = QPushButton("📎")
        attach_btn.setFixedSize(40, 40)
        attach_btn.clicked.connect(self.attach_files)
        attach_btn.setToolTip("Прикрепить файлы")

        # Кнопка голосового ввода
        self.voice_btn = QPushButton("🎤")
        self.voice_btn.setFixedSize(40, 40)
        self.voice_btn.clicked.connect(self.toggle_voice_input)
        self.voice_btn.setToolTip("Голосовой ввод")
        self.voice_btn.setCheckable(True)

        # Кнопка озвучивания ответа
        self.tts_btn = QPushButton("🔊")
        self.tts_btn.setFixedSize(40, 40)
        self.tts_btn.clicked.connect(self.speak_response)
        self.tts_btn.setToolTip("Озвучить ответ")
        self.tts_btn.setEnabled(False)

        send_btn = QPushButton("Отправить")
        send_btn.clicked.connect(self.send_message)
        send_btn.setMinimumHeight(40)

        input_layout.addWidget(attach_btn)
        input_layout.addWidget(self.voice_btn)
        input_layout.addWidget(self.input_field, 1)
        input_layout.addWidget(self.tts_btn)
        input_layout.addWidget(send_btn)

        main_layout.addLayout(top_bar_layout)
        main_layout.addWidget(self.attachments_scroll)
        main_layout.addWidget(chat_splitter, 1)
        main_layout.addLayout(input_layout)

        # Включаем контекстное меню
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

        # Таймер для анимации кнопки голосового ввода
        self.voice_timer = QTimer()
        self.voice_timer.timeout.connect(self.update_voice_button)

    def toggle_voice_input(self):
        """Включение/выключение голосового ввода"""
        if self.is_listening:
            self.stop_voice_input()
        else:
            self.start_voice_input()

    def start_voice_input(self):
        """Запуск распознавания речи"""
        if self.is_speaking:
            QMessageBox.warning(self, "Внимание", "Дождитесь завершения воспроизведения")
            self.voice_btn.setChecked(False)
            return

        self.is_listening = True
        self.voice_btn.setStyleSheet("background-color: #ff4444; color: white;")
        self.voice_timer.start(500)  # Анимация каждые 500ms

        # Запускаем распознавание в отдельном потоке
        self.voice_worker = VoiceWorker(mode="recognize")
        self.voice_worker.speech_recognized.connect(self.on_speech_recognized)
        self.voice_worker.error_occurred.connect(self.on_voice_error)
        self.voice_worker.start()

    def stop_voice_input(self):
        """Остановка распознавания речи"""
        self.is_listening = False
        self.voice_btn.setChecked(False)
        self.voice_btn.setStyleSheet("")
        self.voice_timer.stop()

        if hasattr(self, 'voice_worker'):
            self.voice_worker.terminate()

    def update_voice_button(self):
        """Анимация кнопки голосового ввода"""
        if self.is_listening:
            current_style = self.voice_btn.styleSheet()
            if "background-color: #ff4444" in current_style:
                self.voice_btn.setStyleSheet("background-color: #ff8888; color: white;")
            else:
                self.voice_btn.setStyleSheet("background-color: #ff4444; color: white;")

    def on_speech_recognized(self, text):
        """Обработка распознанной речи"""
        self.input_field.setText(text)
        self.stop_voice_input()
        self.send_message()

    def on_voice_error(self, error_message):
        """Обработка ошибок голосового ввода"""
        self.stop_voice_input()
        QMessageBox.warning(self, "Ошибка голосового ввода", error_message)

    def speak_response(self):
        """Озвучивание ответа модели"""
        if not self.current_ai_response.strip():
            QMessageBox.warning(self, "Внимание", "Нет ответа для озвучивания")
            return

        if self.is_speaking:
            QMessageBox.warning(self, "Внимание", "Уже воспроизводится речь")
            return

        self.is_speaking = True
        self.tts_btn.setStyleSheet("background-color: #44ff44; color: white;")
        self.tts_btn.setEnabled(False)

        # Запускаем синтез речи в отдельном потоке
        self.tts_worker = VoiceWorker(mode="synthesize", text=self.current_ai_response)
        self.tts_worker.voice_playing.connect(self.on_voice_playing)
        self.tts_worker.error_occurred.connect(self.on_tts_error)
        self.tts_worker.start()

    def on_voice_playing(self, playing):
        """Обработка состояния воспроизведения"""
        self.is_speaking = playing
        if not playing:
            self.tts_btn.setStyleSheet("")
            self.tts_btn.setEnabled(True)

    def on_tts_error(self, error_message):
        """Обработка ошибок синтеза речи"""
        self.is_speaking = False
        self.tts_btn.setStyleSheet("")
        self.tts_btn.setEnabled(True)
        QMessageBox.warning(self, "Ошибка синтеза речи", error_message)

    def attach_files(self):
        """Прикрепление файлов к сообщению"""
        file_dialog = QFileDialog()
        file_dialog.setFileMode(QFileDialog.ExistingFiles)
        file_dialog.setNameFilter("Все поддерживаемые файлы (*.txt *.csv *.json *.xml *.yaml *.yml *.html *.css *.js *.py *.java *.cpp *.c *.h *.php *.rb *.go *.rs *.ts *.sql *.sh *.bat *.ps1 *.md *.log *.ini *.cfg *.conf *.xlsx *.xls *.docx *.doc *.pdf);;Текстовые файлы (*.txt *.log *.md);;Код (*.py *.js *.java *.cpp *.c *.h *.html *.css *.php *.rb *.go *.rs *.ts);;Данные (*.csv *.json *.xml *.yaml *.yml);;Все файлы (*)")

        if file_dialog.exec():
            files = file_dialog.selectedFiles()
            for file_path in files:
                if file_path not in self.attachments:
                    self.attachments.append(file_path)
                    self.add_attachment_widget(file_path)

            self.attachments_scroll.setVisible(len(self.attachments) > 0)

    def add_attachment_widget(self, file_path):
        """Добавление виджета прикрепленного файла"""
        attachment_widget = FileAttachmentWidget(file_path)
        self.attachments_layout.addWidget(attachment_widget)
        # Подключаем сигнал удаления
        attachment_widget.destroyed.connect(lambda: self.remove_attachment(file_path))

    def remove_attachment(self, file_path):
        """Удаление прикрепленного файла"""
        if file_path in self.attachments:
            self.attachments.remove(file_path)
        self.attachments_scroll.setVisible(len(self.attachments) > 0)

    def send_message(self):
        user_message = self.input_field.text().strip()
        if not user_message and not self.attachments:
            return

        # Добавляем сообщение в историю пользователя
        self.add_message_to_history(self.user_chat_history, user_message, "user")

        # Очищаем поле ввода
        self.input_field.clear()

        # Получаем выбранную модель
        model_name = self.model_combo.currentText()
        if not model_name:
            QMessageBox.warning(self, "Ошибка", "Не выбрана модель!")
            return

        # Отключаем кнопки во время генерации
        self.input_field.setEnabled(False)
        self.tts_btn.setEnabled(False)

        # Запускаем обработку в отдельном потоке
        self.worker = OllamaWorker(model_name, user_message, self.attachments)
        self.worker.response_received.connect(self.handle_ai_response)
        self.worker.error_occurred.connect(self.handle_error)
        self.worker.finished_signal.connect(self.on_finish)
        self.worker.start()

        # Очищаем вложения после отправки
        self.clear_attachments()

    def clear_attachments(self):
        """Очистка прикрепленных файлов"""
        self.attachments = []
        # Удаляем все виджеты вложений
        while self.attachments_layout.count():
            item = self.attachments_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.attachments_scroll.setVisible(False)

    def handle_ai_response(self, response):
        self.current_ai_response += response
        self.ai_chat_history.moveCursor(QTextCursor.End)
        self.ai_chat_history.insertPlainText(response)
        self.ai_chat_history.moveCursor(QTextCursor.End)

    def handle_error(self, error_message):
        self.ai_chat_history.append(f"\n❌ {error_message}\n")

    def on_finish(self):
        self.input_field.setEnabled(True)
        self.tts_btn.setEnabled(bool(self.current_ai_response.strip()))
        self.sound_manager.play_notification()

    def add_message_to_history(self, history_widget, message, message_type):
        """Добавление сообщения в историю с форматированием"""
        timestamp = datetime.now().strftime("%H:%M:%S")

        if message_type == "user":
            prefix = "👤 Вы:"
            color = "#a6e3a1"  # Зеленый для пользователя
        else:
            prefix = "🤖 AI:"
            color = "#89dceb"  # Голубой для AI

        html_message = f"""
        <div style="margin: 10px 0; padding: 10px; border-radius: 8px; background-color: rgba(0,0,0,0.1);">
            <div style="color: {color}; font-weight: bold;">
                {prefix} <span style="font-size: 0.8em; color: #666;">[{timestamp}]</span>
            </div>
            <div style="margin-top: 5px; white-space: pre-wrap;">{message}</div>
        </div>
        """

        history_widget.moveCursor(QTextCursor.End)
        history_widget.insertHtml(html_message)
        history_widget.moveCursor(QTextCursor.End)

    def refresh_models(self):
        self.model_combo.clear()
        models = self.model_manager.load_models()
        if models:
            self.model_combo.addItems(models)
        else:
            QMessageBox.warning(self, "Ошибка", "Не найдены модели Ollama. Убедитесь, что Ollama установлен и запущен.")

    def download_model(self):
        model_name, ok = QInputDialog.getText(self, "Загрузка модели", "Введите название модели для загрузки (например: llama2):")
        if ok and model_name:
            try:
                subprocess.run(["ollama", "pull", model_name], check=True)
                self.refresh_models()
                QMessageBox.information(self, "Успех", f"Модель {model_name} успешно загружена!")
            except subprocess.CalledProcessError:
                QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить модель {model_name}")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_pos = event.globalPosition().toPoint()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and self.drag_pos:
            self.move(self.pos() + event.globalPosition().toPoint() - self.drag_pos)
            self.drag_pos = event.globalPosition().toPoint()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self.drag_pos = None
        super().mouseReleaseEvent(event)

    def show_context_menu(self, pos):
        context_menu = QMenu(self)

        # Подменю тем
        theme_menu = context_menu.addMenu("🎨 Тема")
        theme_group = QActionGroup(self)

        for theme_name in self.theme_manager.themes.keys():
            action = QAction(theme_name, self)
            action.setCheckable(True)
            action.setChecked(theme_name == self.settings.value("theme", "Темная"))
            action.triggered.connect(lambda checked, name=theme_name: self.change_theme(name))
            theme_group.addAction(action)
            theme_menu.addAction(action)

        custom_theme_action = QAction("Пользовательская...", self)
        custom_theme_action.triggered.connect(self.customize_theme)
        theme_menu.addAction(custom_theme_action)

        # Настройки прозрачности
        opacity_menu = context_menu.addMenu("🔍 Прозрачность")
        opacity_slider_action = QWidgetAction(self)
        opacity_slider = QSlider(Qt.Horizontal)
        opacity_slider.setRange(10, 100)
        opacity_slider.setValue(self.background_opacity)
        opacity_slider.valueChanged.connect(self.set_background_opacity)
        opacity_slider_action.setDefaultWidget(opacity_slider)
        opacity_menu.addAction(opacity_slider_action)

        # Звуковые уведомления
        sound_action = QAction("🔊 Звуковые уведомления", self)
        sound_action.setCheckable(True)
        sound_action.setChecked(self.settings.value("sound_enabled", True, type=bool))
        sound_action.triggered.connect(self.sound_manager.set_enabled)
        context_menu.addAction(sound_action)

        context_menu.addSeparator()

        # Очистка чата
        clear_action = QAction("🗑️ Очистить чат", self)
        clear_action.triggered.connect(self.clear_chat)
        context_menu.addAction(clear_action)

        context_menu.exec(self.mapToGlobal(pos))

    def change_theme(self, theme_name):
        self.settings.setValue("theme", theme_name)
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(theme_name, self.background_opacity)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def customize_theme(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Настройка темы")
        dialog.setMinimumWidth(400)

        layout = QVBoxLayout(dialog)

        color_widgets = {}
        base_theme = self.theme_manager.themes["Темная"]

        for color_name, color_value in base_theme.items():
            row_layout = QHBoxLayout()
            label = QLabel(color_name)
            color_btn = QPushButton()
            color_btn.setFixedSize(50, 25)
            color_btn.setStyleSheet(f"background-color: {color_value};")
            color_btn.clicked.connect(lambda checked, name=color_name, btn=color_btn: self.choose_color(name, btn))

            row_layout.addWidget(label)
            row_layout.addWidget(color_btn)
            layout.addLayout(row_layout)

            color_widgets[color_name] = color_btn

        buttons_layout = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(lambda: self.save_custom_theme(color_widgets, dialog))
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(dialog.reject)

        buttons_layout.addWidget(save_btn)
        buttons_layout.addStretch()
        buttons_layout.addWidget(cancel_btn)

        layout.addLayout(buttons_layout)
        dialog.exec()

    def choose_color(self, color_name, button):
        color = QColorDialog.getColor()
        if color.isValid():
            self.theme_manager.custom_colors[color_name] = color.name()
            button.setStyleSheet(f"background-color: {color.name()};")

    def save_custom_theme(self, color_widgets, dialog):
        self.settings.setValue("theme", "Пользовательская")
        self.change_theme("Пользовательская")
        dialog.accept()

    def set_background_opacity(self, value):
        self.background_opacity = value
        self.settings.setValue("background_opacity", value)
        current_theme = self.settings.value("theme", "Темная")
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(current_theme, value)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def clear_chat(self):
        self.user_chat_history.clear()
        self.ai_chat_history.clear()
        self.current_ai_response = ""
        self.tts_btn.setEnabled(False)

    def load_settings(self):
        theme = self.settings.value("theme", "Темная")
        opacity = self.settings.value("background_opacity", 100, type=int)
        sound_enabled = self.settings.value("sound_enabled", True, type=bool)

        self.background_opacity = opacity
        self.sound_manager.set_enabled(sound_enabled)
        self.change_theme(theme)

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        event.accept()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Chat")
    app.setApplicationVersion("2.0")

    window = ChatWindow()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
