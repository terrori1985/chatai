import sys
import os
import subprocess
from datetime import datetime
import platform
from pathlib import Path
import mimetypes
import chardet
import re
import tempfile
import wave
import pyaudio
import speech_recognition as sr
from gtts import gTTS
import pygame
import requests
import json
import time

from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                              QHBoxLayout, QTextEdit, QLineEdit, QPushButton,
                              QLabel, QComboBox, QMessageBox, QInputDialog,
                              QSlider, QColorDialog, QMenu, QSplitter, QWidgetAction,
                              QDialog, QFileDialog, QScrollArea, QFrame, QCheckBox,
                              QGroupBox, QSpinBox, QProgressBar, QSystemTrayIcon)
from PySide6.QtCore import Qt, QThread, Signal, Slot, QSettings, QUrl, QRegularExpression, QTimer
from PySide6.QtGui import (QPalette, QColor, QTextCursor, QActionGroup, QAction,
                          QFont, QTextCharFormat, QSyntaxHighlighter, QTextDocument,
                          QTextFormat, QGuiApplication, QClipboard, QIcon)
from PySide6.QtMultimedia import QSoundEffect

# --- Вспомогательные классы ---

class VoiceWorker(QThread):
    """Распознавание речи и синтез голоса"""
    speech_recognized = Signal(str)
    error_occurred = Signal(str)
    voice_playing = Signal(bool)

    def __init__(self, mode="recognize", text=None, parent=None):
        super().__init__(parent)
        self.mode = mode  # "recognize" или "synthesize"
        self.text = text
        self._stop_requested = False
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # Инициализация pygame для воспроизведения звука
        pygame.mixer.init()

    def stop(self):
        """Остановить воспроизведение"""
        self._stop_requested = True
        if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()

    def run(self):
        try:
            if self.mode == "recognize":
                self.recognize_speech()
            elif self.mode == "synthesize":
                self.synthesize_speech(self.text)
        except Exception as e:
            self.error_occurred.emit(f"Ошибка голосового модуля: {str(e)}")

    def recognize_speech(self):
        """Распознавание речи с микрофона"""
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source)
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=10)

            text = self.recognizer.recognize_google(audio, language="ru-RU")
            self.speech_recognized.emit(text)

        except sr.WaitTimeoutError:
            self.error_occurred.emit("Таймаут: речь не обнаружена")
        except sr.UnknownValueError:
            self.error_occurred.emit("Речь не распознана")
        except sr.RequestError as e:
            self.error_occurred.emit(f"Ошибка сервиса распознавания: {e}")

    def synthesize_speech(self, text):
        """Синтез речи из текста"""
        try:
            # Создаем временный файл для аудио
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
                tts = gTTS(text=text, lang='ru', slow=False)
                tts.save(tmp_file.name)
                tmp_file_path = tmp_file.name

            # Воспроизводим аудио
            self.voice_playing.emit(True)
            pygame.mixer.music.load(tmp_file_path)
            pygame.mixer.music.play()

            # Ждем завершения воспроизведения или остановки
            while pygame.mixer.music.get_busy():
                if self._stop_requested:
                    pygame.mixer.music.stop()
                    break
                QThread.msleep(100)

            self.voice_playing.emit(False)

            # Удаляем временный файл
            try:
                os.unlink(tmp_file_path)
            except Exception:
                pass

        except Exception as e:
            self.error_occurred.emit(f"Ошибка синтеза речи: {str(e)}")
            self.voice_playing.emit(False)

class CodeHighlighter(QSyntaxHighlighter):
    """Подсветка синтаксиса для различных языков программирования"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []

        # Базовые правила для разных языков
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Bold)

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))

        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8"))

        # Общие ключевые слова для нескольких языков
        keywords = [
            'break', 'case', 'catch', 'class', 'const', 'continue', 'default',
            'delete', 'do', 'else', 'enum', 'export', 'extends', 'false', 'finally',
            'for', 'function', 'if', 'import', 'in', 'instanceof', 'new', 'null',
            'return', 'super', 'switch', 'this', 'throw', 'true', 'try', 'typeof',
            'var', 'void', 'while', 'with', 'yield'
        ]

        for keyword in keywords:
            pattern = r'\b' + keyword + r'\b'
            self.highlighting_rules.append((QRegularExpression(pattern), keyword_format))

        # Строки
        self.highlighting_rules.append((QRegularExpression(r'\".*?\"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'\'.*?\''), string_format))

        # Комментарии
        self.highlighting_rules.append((QRegularExpression(r'//.*'), comment_format))
        self.highlighting_rules.append((QRegularExpression(r'/\*.*?\*/'), comment_format))

        # Числа
        self.highlighting_rules.append((QRegularExpression(r'\b\d+\b'), number_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

class FileAttachmentWidget(QFrame):
    """Виджет для отображения прикрепленного файла"""
    def __init__(self, file_path, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.setFrameStyle(QFrame.Box)
        self.setStyleSheet("""
            QFrame {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px;
                margin: 2px;
            }
        """)

        layout = QVBoxLayout(self)

        file_name = QLabel(Path(file_path).name)
        file_name.setStyleSheet("font-weight: bold;")

        file_info = QLabel(f"{self.get_file_size()} | {self.get_file_type()}")
        file_info.setStyleSheet("color: #666; font-size: 10px;")

        btn_layout = QHBoxLayout()
        view_btn = QPushButton("Просмотр")
        view_btn.clicked.connect(self.view_file)
        view_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        copy_btn = QPushButton("Копировать")
        copy_btn.clicked.connect(self.copy_content)
        copy_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        remove_btn = QPushButton("✕")
        remove_btn.clicked.connect(self.remove_file)
        remove_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")
        remove_btn.setFixedSize(20, 20)

        btn_layout.addWidget(view_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(remove_btn)

        layout.addWidget(file_name)
        layout.addWidget(file_info)
        layout.addLayout(btn_layout)

        self.setFixedHeight(80)

    def get_file_size(self):
        size = os.path.getsize(self.file_path)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"

    def get_file_type(self):
        mime_type, _ = mimetypes.guess_type(self.file_path)
        if mime_type:
            return mime_type.split('/')[-1].upper()
        return Path(self.file_path).suffix.upper().replace('.', '')

    def view_file(self):
        """Просмотр содержимого файла"""
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Просмотр: {Path(self.file_path).name}")
        dialog.setMinimumSize(800, 600)

        layout = QVBoxLayout(dialog)

        # Текстовое поле для содержимого
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)

        # Загружаем содержимое файла
        try:
            content = self.read_file_content()
            text_edit.setPlainText(content)

            # Включаем подсветку синтаксиса для известных форматов
            if self.is_code_file():
                highlighter = CodeHighlighter(text_edit.document())

        except Exception as e:
            text_edit.setPlainText(f"Ошибка чтения файла: {str(e)}")

        layout.addWidget(text_edit)

        # Кнопки
        btn_layout = QHBoxLayout()
        copy_btn = QPushButton("Копировать всё")
        copy_btn.clicked.connect(lambda: self.copy_to_clipboard(content))
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(dialog.accept)

        btn_layout.addWidget(copy_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)

        layout.addLayout(btn_layout)
        dialog.exec()

    def read_file_content(self):
        """Чтение содержимого файла с определением кодировки"""
        try:
            # Определяем кодировку
            with open(self.file_path, 'rb') as f:
                raw_data = f.read()
                result = chardet.detect(raw_data)
                encoding = result['encoding'] or 'utf-8'

            # Читаем файл в правильной кодировке
            with open(self.file_path, 'r', encoding=encoding, errors='replace') as f:
                return f.read()
        except UnicodeDecodeError:
            # Если не удается декодировать как текст, показываем бинарные данные
            return "Бинарный файл - содержимое не может быть отображено как текст"

    def is_code_file(self):
        """Проверяем, является ли файл кодом"""
        code_extensions = {'.py', '.js', '.java', '.cpp', '.c', '.h', '.html',
                          '.css', '.php', '.rb', '.go', '.rs', '.ts', '.json',
                          '.xml', '.yaml', '.yml', '.sql', '.sh', '.bat', '.ps1'}
        return Path(self.file_path).suffix.lower() in code_extensions

    def copy_content(self):
        """Копирование содержимого файла в буфер обмена"""
        try:
            content = self.read_file_content()
            self.copy_to_clipboard(content)
            QMessageBox.information(self, "Успех", "Содержимое файла скопировано в буфер обмена")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось скопировать файл: {str(e)}")

    def copy_to_clipboard(self, text):
        """Копирование текста в буфер обмена"""
        clipboard = QGuiApplication.clipboard()
        clipboard.setText(text)

    def remove_file(self):
        """Удаление прикрепленного файла"""
        self.deleteLater()

class OllamaWorker(QThread):
    """Отвечает за асинхронный запуск модели Ollama."""
    response_received = Signal(str)
    error_occurred = Signal(str)
    finished_signal = Signal()
    thinking_started = Signal()
    thinking_finished = Signal()

    def __init__(self, model_name, prompt, attachments=None, server_url="http://localhost:11434"):
        super().__init__()
        self.model_name = model_name
        self.prompt = prompt
        self.attachments = attachments or []
        self.server_url = server_url

    def run(self):
        try:
            self.thinking_started.emit()
            
            # Подготавливаем полный промпт с вложениями
            full_prompt = self.prompt

            if self.attachments:
                full_prompt += "\n\n--- ПРИКРЕПЛЕННЫЕ ФАЙЛЫ ---\n"
                for i, attachment in enumerate(self.attachments, 1):
                    try:
                        content = self.read_file_content(attachment)
                        file_name = Path(attachment).name
                        file_extension = Path(attachment).suffix.lower()

                        full_prompt += f"\n--- ФАЙЛ {i}: {file_name} ---\n"
                        full_prompt += f"Расширение: {file_extension}\n"
                        full_prompt += f"Содержимое:\n```{file_extension}\n{content}\n```\n"

                    except Exception as e:
                        full_prompt += f"\n--- ФАЙЛ {i}: {Path(attachment).name} ---\n"
                        full_prompt += f"ОШИБКА ЧТЕНИЯ: {str(e)}\n"

                full_prompt += "\n--- КОНЕЦ ФАЙЛОВ ---\n\n"
                full_prompt += "Проанализируй прикрепленные файлы и ответь на мой запрос с учетом их содержимого.\n"

            # Используем API Ollama вместо subprocess
            headers = {'Content-Type': 'application/json'}
            data = {
                'model': self.model_name,
                'prompt': full_prompt,
                'stream': True
            }

            response = requests.post(
                f"{self.server_url}/api/generate",
                headers=headers,
                json=data,
                stream=True
            )

            if response.status_code != 200:
                self.error_occurred.emit(f"Ошибка API: {response.status_code} - {response.text}")
                return

            full_response = ""
            for line in response.iter_lines():
                if line:
                    try:
                        json_data = json.loads(line)
                        if 'response' in json_data:
                            chunk = json_data['response']
                            full_response += chunk
                            self.response_received.emit(chunk)
                        if json_data.get('done', False):
                            break
                    except json.JSONDecodeError:
                        continue

            self.thinking_finished.emit()
            self.finished_signal.emit()

        except requests.exceptions.ConnectionError:
            self.error_occurred.emit("Не удалось подключиться к серверу Ollama")
            self.finished_signal.emit()
        except requests.exceptions.Timeout:
            self.error_occurred.emit("Таймаут подключения к серверу Ollama")
            self.finished_signal.emit()
        except Exception as e:
            self.error_occurred.emit(f"Ошибка: {str(e)}")
            self.finished_signal.emit()

    def read_file_content(self, file_path):
        """Чтение содержимого файла с обработкой различных кодировок"""
        try:
            with open(file_path, 'rb') as f:
                raw_data = f.read()

            result = chardet.detect(raw_data)
            encoding = result['encoding'] or 'utf-8'

            try:
                content = raw_data.decode(encoding, errors='replace')
                max_file_size = 10000
                if len(content) > max_file_size:
                    content = content[:max_file_size] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"
                return content
            except UnicodeDecodeError:
                for alt_encoding in ['utf-8', 'latin-1', 'cp1251', 'cp1252']:
                    try:
                        content = raw_data.decode(alt_encoding, errors='replace')
                        if len(content) > 10000:
                            content = content[:10000] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"
                        return content
                    except UnicodeDecodeError:
                        continue
                return f"БИНАРНЫЙ ФАЙЛ. Размер: {len(raw_data)} байт."

        except Exception as e:
            return f"ОШИБКА ЧТЕНИЯ ФАЙЛА: {str(e)}"

class ModelManager:
    """Управляет списком доступных моделей Ollama."""
    def load_models(self, server_url="http://localhost:11434"):
        models = []
        try:
            response = requests.get(f"{server_url}/api/tags", timeout=10)
            if response.status_code == 200:
                data = response.json()
                for model in data.get('models', []):
                    models.append(model['name'])
        except requests.exceptions.ConnectionError:
            print("Не удалось подключиться к серверу Ollama")
        except Exception as e:
            print(f"Ошибка загрузки моделей: {e}")
        return models

    def check_connection(self, server_url="http://localhost:11434"):
        """Проверка подключения к серверу Ollama"""
        try:
            response = requests.get(f"{server_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False

class SoundManager:
    """Управляет звуковыми уведомлениями."""
    def __init__(self):
        self.enabled = True
        self.sound_file = ""
        self.sound_effect = QSoundEffect()
        self.load_default_sound()

    def load_default_sound(self):
        """Загрузка звука по умолчанию"""
        default_path = Path("notification.wav")
        if default_path.exists():
            self.set_sound_file(str(default_path))

    def set_enabled(self, enabled):
        """Установить состояние звука"""
        self.enabled = enabled

    def set_sound_file(self, file_path):
        """Установить файл звука"""
        self.sound_file = file_path
        if file_path and Path(file_path).exists():
            self.sound_effect.setSource(QUrl.fromLocalFile(file_path))

    def play_notification(self):
        if self.enabled and self.sound_effect.source().isValid():
            self.sound_effect.play()

class ThemeManager:
    """
    Управляет темами (светлая, темная, кастомная) и генерирует стили.
    """
    def __init__(self):
        self.themes = {
            "Темная": {
                "background": "#1e1e2e", "text": "#cdd6f4", "base": "#181825",
                "accent": "#89b4fa", "user_message": "#a6e3a1", "ai_message": "#89dceb",
                "system_message": "#f38ba8", "border": "#45475a",
                "button": "#585b70", "button_text": "#cdd6f4"
            },
            "Светлая": {
                "background": "#eff1f5", "text": "#4c4f69", "base": "#ffffff",
                "accent": "#1e66f5", "user_message": "#40a02b", "ai_message": "#04a5e5",
                "system_message": "#d20f39", "border": "#dce0e8",
                "button": "#dce0e8", "button_text": "#4c4f69"
            },
            "Пользовательская": {
                "background": "#1e1e2e", "text": "#cdd6f4", "base": "#181825",
                "accent": "#89b4fa", "user_message": "#a6e3a1", "ai_message": "#89dceb",
                "system_message": "#f38ba8", "border": "#45475a",
                "button": "#585b70", "button_text": "#cdd6f4"
            }
        }
        self.custom_colors = {}

    def get_palette_and_style(self, theme_name, background_opacity=100):
        colors = self.themes.get(theme_name, {})
        if theme_name == "Пользовательская":
            colors = {**colors, **self.custom_colors}

        if not colors:
            return QPalette(), "", {}

        bg_color = QColor(colors["background"])
        base_color = QColor(colors["base"])

        if background_opacity < 100:
            bg_alpha = int(255 * (background_opacity / 100.0))
            base_alpha = int(255 * min(1.0, (background_opacity / 100.0) + 0.2))

            bg_color.setAlpha(bg_alpha)
            base_color.setAlpha(base_alpha)

        palette = QPalette()
        palette.setColor(QPalette.Window, bg_color)
        palette.setColor(QPalette.WindowText, QColor(colors["text"]))
        palette.setColor(QPalette.Base, base_color)
        palette.setColor(QPalette.AlternateBase, QColor(colors["border"]))
        palette.setColor(QPalette.Text, QColor(colors["text"]))
        palette.setColor(QPalette.Button, QColor(colors["button"]))
        palette.setColor(QPalette.ButtonText, QColor(colors["button_text"]))
        palette.setColor(QPalette.Highlight, QColor(colors["accent"]))
        palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))

        bg_rgba = f"rgba({bg_color.red()}, {bg_color.green()}, {bg_color.blue()}, {bg_color.alpha()})"
        base_rgba = f"rgba({base_color.red()}, {base_color.green()}, {base_color.blue()}, {base_color.alpha()})"

        stylesheet = f"""
            QMainWindow {{
                background-color: transparent;
                border: none;
            }}
            QWidget#centralWidget {{
                background-color: {bg_rgba};
                border-radius: 12px;
                border: 1px solid {colors["border"]};
            }}
            QTextEdit, QLineEdit, QComboBox {{
                background-color: {base_rgba};
                color: {colors["text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 10px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 10pt;
            }}
            QPushButton {{
                background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {colors['button']},
                    stop:1 {QColor(colors['button']).darker(110).name()}
                );
                color: {colors["button_text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {colors["accent"]};
                color: #ffffff;
                border: 1px solid {colors["accent"]};
            }}
            QSplitter::handle {{
                background-color: {colors["border"]};
            }}
            QSplitter::handle:horizontal {{ width: 1px; }}
            QMenu {{
                background-color: {base_rgba};
                border: 1px solid {colors["border"]};
                color: {colors["text"]};
            }}
            QMenu::item:selected {{
                background-color: {colors["accent"]};
                color: #ffffff;
            }}
            *:focus {{
                border: 1px solid {colors["accent"]};
            }}
        """
        return palette, stylesheet, colors

class SettingsDialog(QDialog):
    """Диалог настроек"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("Настройки")
        self.setMinimumWidth(500)
        
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Настройки сервера Ollama
        server_group = QGroupBox("Настройки сервера Ollama")
        server_layout = QVBoxLayout(server_group)
        
        server_url_layout = QHBoxLayout()
        server_url_layout.addWidget(QLabel("URL сервера:"))
        self.server_url_edit = QLineEdit()
        self.server_url_edit.setPlaceholderText("http://localhost:11434")
        server_url_layout.addWidget(self.server_url_edit)
        server_layout.addLayout(server_url_layout)
        
        # Тестирование подключения
        test_btn = QPushButton("Проверить подключение")
        test_btn.clicked.connect(self.test_connection)
        server_layout.addWidget(test_btn)
        
        layout.addWidget(server_group)
        
        # Настройки звука
        sound_group = QGroupBox("Настройки звука")
        sound_layout = QVBoxLayout(sound_group)
        
        self.sound_enabled = QCheckBox("Включить звуковые уведомления")
        sound_layout.addWidget(self.sound_enabled)
        
        sound_file_layout = QHBoxLayout()
        sound_file_layout.addWidget(QLabel("Файл звука:"))
        self.sound_file_edit = QLineEdit()
        self.sound_file_edit.setReadOnly(True)
        sound_file_layout.addWidget(self.sound_file_edit)
        
        browse_btn = QPushButton("Обзор...")
        browse_btn.clicked.connect(self.browse_sound_file)
        sound_file_layout.addWidget(browse_btn)
        
        test_sound_btn = QPushButton("Тест")
        test_sound_btn.clicked.connect(self.test_sound)
        sound_file_layout.addWidget(test_sound_btn)
        
        sound_layout.addLayout(sound_file_layout)
        layout.addWidget(sound_group)
        
        # Кнопки
        button_layout = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save_settings)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(save_btn)
        button_layout.addStretch()
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)

    def load_settings(self):
        settings = QSettings("AI-Chat", "OllamaClientRefactored")
        self.server_url_edit.setText(settings.value("server_url", "http://localhost:11434"))
        self.sound_enabled.setChecked(settings.value("sound_enabled", True, type=bool))
        self.sound_file_edit.setText(settings.value("sound_file", ""))

    def test_connection(self):
        url = self.server_url_edit.text().strip() or "http://localhost:11434"
        if self.parent.model_manager.check_connection(url):
            QMessageBox.information(self, "Успех", "Подключение к серверу Ollama установлено!")
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось подключиться к серверу Ollama")

    def browse_sound_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл звука", "", "Audio Files (*.wav *.mp3 *.ogg)"
        )
        if file_path:
            self.sound_file_edit.setText(file_path)

    def test_sound(self):
        if self.sound_file_edit.text():
            sound_effect = QSoundEffect()
            sound_effect.setSource(QUrl.fromLocalFile(self.sound_file_edit.text()))
            sound_effect.play()

    def save_settings(self):
        settings = QSettings("AI-Chat", "OllamaClientRefactored")
        settings.setValue("server_url", self.server_url_edit.text())
        settings.setValue("sound_enabled", self.sound_enabled.isChecked())
        settings.setValue("sound_file", self.sound_file_edit.text())
        
        # Обновляем настройки в родительском окне
        self.parent.load_settings()
        self.accept()

class CustomThemeDialog(QDialog):
    """Диалог настройки пользовательской темы"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("Настройка пользовательской темы")
        self.setMinimumWidth(400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)
        
        colors = self.parent.theme_manager.themes["Пользовательская"]
        self.color_buttons = {}
        
        for color_name, color_value in colors.items():
            row_layout = QHBoxLayout()
            label = QLabel(color_name)
            color_btn = QPushButton()
            color_btn.setFixedSize(60, 30)
            color_btn.setStyleSheet(f"background-color: {color_value}; border: 1px solid #ccc;")
            color_btn.clicked.connect(lambda checked, name=color_name: self.choose_color(name))
            
            row_layout.addWidget(label, 1)
            row_layout.addWidget(color_btn)
            scroll_layout.addLayout(row_layout)
            self.color_buttons[color_name] = color_btn
        
        scroll.setWidget(scroll_widget)
        layout.addWidget(scroll)
        
        button_layout = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save_theme)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(save_btn)
        button_layout.addStretch()
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)

    def choose_color(self, color_name):
        color = QColorDialog.getColor()
        if color.isValid():
            self.parent.theme_manager.custom_colors[color_name] = color.name()
            self.color_buttons[color_name].setStyleSheet(f"background-color: {color.name()}; border: 1px solid #ccc;")

    def save_theme(self):
        self.parent.settings.setValue("theme", "Пользовательская")
        self.parent.change_theme("Пользовательская")
        self.accept()

class ChatWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.theme_manager = ThemeManager()
        self.model_manager = ModelManager()
        self.sound_manager = SoundManager()
        self.settings = QSettings("AI-Chat", "OllamaClientRefactored")

        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.current_ai_response = ""
        self.drag_pos = None
        self.background_opacity = 100
        self.attachments = []
        self.is_listening = False
        self.is_speaking = False
        self.server_url = "http://localhost:11434"
        self.connection_status = False
        self.tts_worker = None
        self.ollama_worker = None
        # Акцентный цвет текста в чате (None = использовать цвет темы)
        self.chat_accent_color = None

        self.init_ui()
        self.load_settings()
        
        # Таймер для проверки подключения
        self.connection_timer = QTimer()
        self.connection_timer.timeout.connect(self.check_connection_status)
        self.connection_timer.start(5000)  # Проверка каждые 5 секунд
        self.check_connection_status()

    def init_ui(self):
        """Компактный интерфейс с разделением истории"""
        self.setWindowTitle("AI Chat")
        self.setGeometry(100, 100, 1200, 800)

        self.central_widget = QWidget()
        self.central_widget.setObjectName("centralWidget")
        self.setCentralWidget(self.central_widget)

        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(10)

        # --- Верхняя панель управления ---
        top_bar_layout = QHBoxLayout()
        
        # Индикатор подключения
        self.connection_indicator = QLabel("●")
        self.connection_indicator.setFixedWidth(20)
        self.connection_indicator.setAlignment(Qt.AlignCenter)
        
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(35)
        
        refresh_btn = QPushButton("Обновить")
        refresh_btn.clicked.connect(self.refresh_models)
        
        download_btn = QPushButton("Загрузить модель")
        download_btn.clicked.connect(self.download_model)
        
        settings_btn = QPushButton("⚙️")
        settings_btn.setFixedSize(30, 30)
        settings_btn.clicked.connect(self.show_settings)
        settings_btn.setToolTip("Настройки")

        # Кнопки управления окном
        minimize_btn = QPushButton("—")
        minimize_btn.setFixedSize(30, 30)
        minimize_btn.clicked.connect(self.showMinimized)
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.clicked.connect(self.close)

        top_bar_layout.addWidget(self.connection_indicator)
        top_bar_layout.addWidget(QLabel("Модель:"))
        top_bar_layout.addWidget(self.model_combo, 1)
        top_bar_layout.addWidget(refresh_btn)
        top_bar_layout.addWidget(download_btn)
        top_bar_layout.addWidget(settings_btn)
        top_bar_layout.addStretch()
        top_bar_layout.addWidget(minimize_btn)
        top_bar_layout.addWidget(close_btn)

        # --- Индикатор мышления ---
        self.thinking_indicator = QProgressBar()
        self.thinking_indicator.setRange(0, 0)  # Бесконечная анимация
        self.thinking_indicator.setVisible(False)
        self.thinking_indicator.setFixedHeight(3)
        self.thinking_indicator.setTextVisible(False)

        # --- Область прикрепленных файлов ---
        self.attachments_scroll = QScrollArea()
        self.attachments_scroll.setMaximumHeight(100)
        self.attachments_scroll.setWidgetResizable(True)
        self.attachments_widget = QWidget()
        self.attachments_layout = QHBoxLayout(self.attachments_widget)
        self.attachments_layout.setContentsMargins(5, 5, 5, 5)
        self.attachments_scroll.setWidget(self.attachments_widget)
        self.attachments_scroll.setVisible(False)

        # --- Разделенная область чатов ---
        chat_splitter = QSplitter(Qt.Horizontal)

        user_widget = QWidget()
        user_layout = QVBoxLayout(user_widget)
        user_layout.setContentsMargins(0, 0, 0, 0)
        user_label = QLabel("Ваши сообщения")
        user_label.setAlignment(Qt.AlignCenter)
        user_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.user_chat_history = QTextEdit()
        self.user_chat_history.setReadOnly(True)
        self.user_chat_history.setPlaceholderText("Введите сообщение...")
        # Убираем фон у текста в чате
        self.user_chat_history.setStyleSheet("background-color: transparent; border: none;")
        user_layout.addWidget(user_label)
        user_layout.addWidget(self.user_chat_history)

        ai_widget = QWidget()
        ai_layout = QVBoxLayout(ai_widget)
        ai_layout.setContentsMargins(0, 0, 0, 0)
        ai_label = QLabel("Ответы модели")
        ai_label.setAlignment(Qt.AlignCenter)
        ai_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.ai_chat_history = QTextEdit()
        self.ai_chat_history.setReadOnly(True)
        self.ai_chat_history.setPlaceholderText("Здесь появятся ответы...")
        # Убираем фон у текста в чате
        self.ai_chat_history.setStyleSheet("background-color: transparent; border: none;")
        ai_layout.addWidget(ai_label)
        ai_layout.addWidget(self.ai_chat_history)

        chat_splitter.addWidget(user_widget)
        chat_splitter.addWidget(ai_widget)
        chat_splitter.setSizes([self.width() // 2, self.width() // 2])

        # --- Поле ввода и кнопки ---
        input_layout = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Введите ваше сообщение...")
        self.input_field.returnPressed.connect(self.send_message)
        self.input_field.setMinimumHeight(40)

        # Кнопка прикрепления файлов
        attach_btn = QPushButton("📎")
        attach_btn.setFixedSize(40, 40)
        attach_btn.clicked.connect(self.attach_files)
        attach_btn.setToolTip("Прикрепить файлы")

        # Кнопка голосового ввода
        self.voice_btn = QPushButton("🎤")
        self.voice_btn.setFixedSize(40, 40)
        self.voice_btn.clicked.connect(self.toggle_voice_input)
        self.voice_btn.setToolTip("Голосовой ввод")
        self.voice_btn.setCheckable(True)

        # Кнопка озвучивания / остановки озвучки
        self.tts_btn = QPushButton("🔊")
        self.tts_btn.setFixedSize(40, 40)
        self.tts_btn.clicked.connect(self.toggle_tts)
        self.tts_btn.setToolTip("Озвучить ответ")
        self.tts_btn.setEnabled(False)

        send_btn = QPushButton("Отправить")
        send_btn.clicked.connect(self.send_message)
        send_btn.setMinimumHeight(40)

        # Кнопка разговорного режима
        self.conv_btn = QPushButton("💬")
        self.conv_btn.setFixedSize(40, 40)
        self.conv_btn.setToolTip("Разговорный режим")
        self.conv_btn.clicked.connect(self.open_conversation_mode)

        # Кнопка компактного разговорного режима
        self.conv_compact_btn = QPushButton("🗨")
        self.conv_compact_btn.setFixedSize(40, 40)
        self.conv_compact_btn.setToolTip("Компактный разговорный режим")
        self.conv_compact_btn.clicked.connect(self.open_conversation_mode_compact)

        # Кнопка акцентного цвета текста чата
        self.accent_color_btn = QPushButton("🎨")
        self.accent_color_btn.setFixedSize(40, 40)
        self.accent_color_btn.setToolTip("Акцентный цвет текста в чате")
        self.accent_color_btn.clicked.connect(self.choose_chat_accent_color)

        input_layout.addWidget(attach_btn)
        input_layout.addWidget(self.voice_btn)
        input_layout.addWidget(self.accent_color_btn)
        input_layout.addWidget(self.conv_btn)
        input_layout.addWidget(self.conv_compact_btn)
        input_layout.addWidget(self.input_field, 1)
        input_layout.addWidget(self.tts_btn)
        input_layout.addWidget(send_btn)

        main_layout.addLayout(top_bar_layout)
        main_layout.addWidget(self.thinking_indicator)
        main_layout.addWidget(self.attachments_scroll)
        main_layout.addWidget(chat_splitter, 1)
        main_layout.addLayout(input_layout)

        # Включаем контекстное меню
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

        # Таймер для анимации кнопки голосового ввода
        self.voice_timer = QTimer()
        self.voice_timer.timeout.connect(self.update_voice_button)

    def load_settings(self):
        """Загрузка настроек из реестра/файла"""
        self.server_url = self.settings.value("server_url", "http://localhost:11434")
        self.sound_manager.set_enabled(self.settings.value("sound_enabled", True, type=bool))
        sound_file = self.settings.value("sound_file", "")
        if sound_file:
            self.sound_manager.set_sound_file(sound_file)
        
        self.background_opacity = self.settings.value("background_opacity", 100, type=int)
        saved_accent = self.settings.value("chat_accent_color", "")
        if saved_accent:
            self.chat_accent_color = saved_accent
            self.accent_color_btn.setStyleSheet(
                f"background-color: {saved_accent}; border-radius: 8px;"
            )
            self.accent_color_btn.setToolTip(f"Акцентный цвет: {saved_accent}")
        theme = self.settings.value("theme", "Темная")
        self.change_theme(theme)

    def show_settings(self):
        """Показать диалог настроек"""
        dialog = SettingsDialog(self)
        dialog.exec()

    def show_context_menu(self, pos):
        context_menu = QMenu(self)

        # Акцентный цвет текста чата
        accent_action = context_menu.addAction("🖌 Цвет текста ответов...")
        accent_action.triggered.connect(self.choose_chat_accent_color)
        if self.chat_accent_color:
            reset_accent_action = context_menu.addAction("↺ Сбросить цвет текста")
            reset_accent_action.triggered.connect(self._reset_chat_accent_color)
        context_menu.addSeparator()

        # Подменю тем
        theme_menu = context_menu.addMenu("🎨 Тема")
        theme_group = QActionGroup(self)

        for theme_name in self.theme_manager.themes.keys():
            action = QAction(theme_name, self)
            action.setCheckable(True)
            action.setChecked(theme_name == self.settings.value("theme", "Темная"))
            action.triggered.connect(lambda checked, name=theme_name: self.change_theme(name))
            theme_group.addAction(action)
            theme_menu.addAction(action)

        custom_theme_action = QAction("Пользовательская...", self)
        custom_theme_action.triggered.connect(self.customize_theme)
        theme_menu.addAction(custom_theme_action)

        # Настройки прозрачности
        opacity_menu = context_menu.addMenu("🔍 Прозрачность")
        for opacity in [100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 0]:
            action = QAction(f"{opacity}%", self)
            action.triggered.connect(lambda checked, o=opacity: self.set_background_opacity(o))
            opacity_menu.addAction(action)

        # Звуковые уведомления
        sound_action = QAction("🔊 Звуковые уведомления", self)
        sound_action.setCheckable(True)
        sound_action.setChecked(self.settings.value("sound_enabled", True, type=bool))
        sound_action.triggered.connect(self.sound_manager.set_enabled)
        context_menu.addAction(sound_action)

        context_menu.addSeparator()

        # Очистка чата
        clear_action = QAction("🗑️ Очистить чат", self)
        clear_action.triggered.connect(self.clear_chat)
        context_menu.addAction(clear_action)

        context_menu.exec(self.mapToGlobal(pos))

    def customize_theme(self):
        """Настройка пользовательской темы"""
        dialog = CustomThemeDialog(self)
        dialog.exec()

    def change_theme(self, theme_name):
        self.settings.setValue("theme", theme_name)
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(theme_name, self.background_opacity)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def set_background_opacity(self, value):
        self.background_opacity = value
        self.settings.setValue("background_opacity", value)
        current_theme = self.settings.value("theme", "Темная")
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(current_theme, value)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def check_connection_status(self):
        """Проверка статуса подключения к серверу Ollama"""
        new_status = self.model_manager.check_connection(self.server_url)
        if new_status != self.connection_status:
            self.connection_status = new_status
            self.update_connection_indicator()
            
        if new_status and not self.model_combo.count():
            self.refresh_models()

    def update_connection_indicator(self):
        """Обновление индикатора подключения"""
        if self.connection_status:
            self.connection_indicator.setText("●")
            self.connection_indicator.setStyleSheet("color: green; font-weight: bold;")
            self.connection_indicator.setToolTip("Подключено к серверу Ollama")
        else:
            self.connection_indicator.setText("●")
            self.connection_indicator.setStyleSheet("color: red; font-weight: bold;")
            self.connection_indicator.setToolTip("Нет подключения к серверу Ollama")

    def refresh_models(self):
        """Обновление списка моделей"""
        self.model_combo.clear()
        models = self.model_manager.load_models(self.server_url)
        if models:
            self.model_combo.addItems(models)
        else:
            self.model_combo.addItem("Нет доступных моделей")

    def download_model(self):
        """Диалог загрузки новой модели"""
        model_name, ok = QInputDialog.getText(
            self, "Загрузка модели", "Введите название модели для загрузки:"
        )
        if ok and model_name:
            try:
                # Запускаем процесс загрузки в отдельном потоке
                subprocess.Popen([
                    "ollama", "pull", model_name.strip()
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                QMessageBox.information(
                    self, "Загрузка начата",
                    f"Модель '{model_name}' начала загружаться.\n"
                    f"Проверьте консоль для отслеживания прогресса."
                )
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось начать загрузку: {str(e)}")

    def attach_files(self):
        """Прикрепление файлов"""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self, "Выберите файлы для прикрепления", "", "Все файлы (*)"
        )
        for file_path in file_paths:
            if file_path not in self.attachments:
                self.attachments.append(file_path)
                widget = FileAttachmentWidget(file_path)
                widget.destroyed.connect(lambda: self.remove_attachment(file_path))
                self.attachments_layout.addWidget(widget)

        if self.attachments:
            self.attachments_scroll.setVisible(True)

    def remove_attachment(self, file_path):
        """Удаление прикрепленного файла"""
        if file_path in self.attachments:
            self.attachments.remove(file_path)
        if not self.attachments:
            self.attachments_scroll.setVisible(False)

    def toggle_voice_input(self):
        """Переключение голосового ввода"""
        if self.is_listening:
            self.stop_voice_input()
        else:
            self.start_voice_input()

    def start_voice_input(self):
        """Начало голосового ввода"""
        self.is_listening = True
        self.voice_btn.setChecked(True)
        self.voice_btn.setStyleSheet("background-color: #ff4444;")
        self.voice_btn.setToolTip("Остановить запись")

        self.voice_worker = VoiceWorker(mode="recognize")
        self.voice_worker.speech_recognized.connect(self.on_speech_recognized)
        self.voice_worker.error_occurred.connect(self.on_voice_error)
        self.voice_worker.start()

    def stop_voice_input(self):
        """Остановка голосового ввода"""
        self.is_listening = False
        self.voice_btn.setChecked(False)
        self.voice_btn.setStyleSheet("")
        self.voice_btn.setToolTip("Голосовой ввод")

    def update_voice_button(self):
        """Анимация кнопки голосового ввода"""
        if self.is_listening:
            current_style = self.voice_btn.styleSheet()
            if "background-color: #ff4444" in current_style:
                self.voice_btn.setStyleSheet("background-color: #ff8888; color: white;")
            else:
                self.voice_btn.setStyleSheet("background-color: #ff4444; color: white;")

    def on_speech_recognized(self, text):
        """Обработка распознанной речи"""
        self.input_field.setText(text)
        self.stop_voice_input()
        self.send_message()

    def on_voice_error(self, error_message):
        """Обработка ошибок голосового ввода"""
        self.stop_voice_input()
        QMessageBox.warning(self, "Ошибка голосового ввода", error_message)

    def toggle_tts(self):
        """Озвучить / остановить озвучку"""
        if self.is_speaking:
            self.stop_tts()
        else:
            self.speak_response()

    def speak_response(self):
        """Озвучивание ответа AI"""
        if not self.current_ai_response.strip():
            QMessageBox.warning(self, "Внимание", "Нет ответа для озвучивания")
            return

        if self.is_speaking:
            return

        self.is_speaking = True
        self.tts_btn.setText("⏹")
        self.tts_btn.setToolTip("Остановить озвучку")
        self.tts_btn.setStyleSheet("background-color: #44ff44; color: white;")

        self.tts_worker = VoiceWorker(mode="synthesize", text=self.current_ai_response)
        self.tts_worker.voice_playing.connect(self.on_voice_playing)
        self.tts_worker.error_occurred.connect(self.on_tts_error)
        self.tts_worker.start()

    def stop_tts(self):
        """Остановить воспроизведение"""
        if self.tts_worker:
            self.tts_worker.stop()

    def on_voice_playing(self, playing):
        """Обработка состояния воспроизведения"""
        self.is_speaking = playing
        if not playing:
            self.tts_btn.setText("🔊")
            self.tts_btn.setToolTip("Озвучить ответ")
            self.tts_btn.setStyleSheet("")

    def on_tts_error(self, error_message):
        """Обработка ошибок синтеза речи"""
        self.is_speaking = False
        self.tts_btn.setText("🔊")
        self.tts_btn.setToolTip("Озвучить ответ")
        self.tts_btn.setStyleSheet("")
        self.tts_btn.setEnabled(True)
        QMessageBox.warning(self, "Ошибка синтеза речи", error_message)

    def choose_chat_accent_color(self):
        """Выбор акцентного цвета текста в чате"""
        color = QColorDialog.getColor(
            QColor(self.chat_accent_color) if self.chat_accent_color else QColor("#89dceb"),
            self, "Акцентный цвет текста в чате"
        )
        if color.isValid():
            self.chat_accent_color = color.name()
            self.accent_color_btn.setToolTip(f"Акцентный цвет: {self.chat_accent_color}")
            self.accent_color_btn.setStyleSheet(
                f"background-color: {self.chat_accent_color}; border-radius: 8px;"
            )
        # Если пользователь отменил — ничего не меняем

    def _reset_chat_accent_color(self):
        """Сбросить акцентный цвет к цвету темы"""
        self.chat_accent_color = None
        self.accent_color_btn.setStyleSheet("")
        self.accent_color_btn.setToolTip("Акцентный цвет текста в чате")

    def _get_ai_color(self):
        """Возвращает текущий цвет текста ответов AI"""
        if self.chat_accent_color:
            return self.chat_accent_color
        current_theme = self.settings.value("theme", "Темная")
        return self.theme_manager.themes.get(current_theme, {}).get("ai_message", "#89dceb")

    def open_conversation_mode(self):
        """Открыть разговорный режим"""
        self._conv_window = ConversationModeWindow(self, compact=False)
        self._conv_window.show()

    def open_conversation_mode_compact(self):
        """Открыть компактный разговорный режим"""
        self._conv_compact_window = ConversationModeWindow(self, compact=True)
        screen = QApplication.primaryScreen().availableGeometry()
        self._conv_compact_window.move(screen.right() - 280, screen.bottom() - 110)
        self._conv_compact_window.show()

    def send_message(self):
        """Отправка сообщения"""
        user_message = self.input_field.text().strip()
        if not user_message and not self.attachments:
            return

        selected_model = self.model_combo.currentText()
        if selected_model == "Нет доступных моделей":
            QMessageBox.warning(self, "Ошибка", "Нет доступных моделей для использования")
            return

        # Добавляем сообщение пользователя в историю
        timestamp = datetime.now().strftime("%H:%M:%S")
        current_theme = self.settings.value("theme", "Темная")
        user_color = self.theme_manager.themes.get(current_theme, {}).get("user_message", "#a6e3a1")
        user_message_html = f"""
        <div style='color: {user_color}; padding: 5px;'>
            <strong>Вы ({timestamp}):</strong><br>{user_message}
        </div>
        """
        self.user_chat_history.append(user_message_html)

        if self.attachments:
            files_info = "<br>".join([f"📎 {Path(f).name}" for f in self.attachments])
            self.user_chat_history.append(f"""
            <div style='color: #f9c74f; padding: 5px;'>
                <strong>Прикрепленные файлы:</strong><br>{files_info}
            </div>
            """)

        self.input_field.clear()
        self.current_ai_response = ""
        self.ai_chat_history.clear()

        # Запускаем обработку AI
        self.ollama_worker = OllamaWorker(
            model_name=selected_model,
            prompt=user_message,
            attachments=self.attachments,
            server_url=self.server_url
        )
        self.ollama_worker.response_received.connect(self.on_ai_response)
        self.ollama_worker.error_occurred.connect(self.on_ai_error)
        self.ollama_worker.finished_signal.connect(self.on_ai_finished)
        self.ollama_worker.thinking_started.connect(self.on_thinking_started)
        self.ollama_worker.thinking_finished.connect(self.on_thinking_finished)
        self.ollama_worker.start()

    def on_thinking_started(self):
        """Начало обработки модели"""
        self.thinking_indicator.setVisible(True)
        self.tts_btn.setEnabled(False)

    def on_thinking_finished(self):
        """Завершение обработки модели"""
        self.thinking_indicator.setVisible(False)

    def on_ai_response(self, chunk):
        """Обработка ответа AI по частям"""
        self.current_ai_response += chunk
        # Обновляем ответ в реальном времени
        timestamp = datetime.now().strftime("%H:%M:%S")
        ai_color = self._get_ai_color()
        ai_message_html = f"""
        <div style='color: {ai_color}; padding: 5px;'>
            <strong>AI ({timestamp}):</strong><br>{self.current_ai_response}
        </div>
        """
        # Сохраняем позицию скролла
        scrollbar = self.ai_chat_history.verticalScrollBar()
        at_bottom = scrollbar.value() == scrollbar.maximum()
        
        # Обновляем содержимое
        self.ai_chat_history.clear()
        self.ai_chat_history.append(ai_message_html)
        
        # Восстанавливаем позицию скролла
        if at_bottom:
            scrollbar.setValue(scrollbar.maximum())

    def on_ai_error(self, error_msg):
        """Обработка ошибок AI"""
        self.thinking_indicator.setVisible(False)
        timestamp = datetime.now().strftime("%H:%M:%S")
        err_theme = self.settings.value("theme", "Темная")
        err_color = self.theme_manager.themes.get(err_theme, {}).get("system_message", "#f38ba8")
        error_html = f"""
        <div style='color: {err_color}; padding: 5px;'>
            <strong>Ошибка ({timestamp}):</strong><br>{error_msg}
        </div>
        """
        self.ai_chat_history.append(error_html)
        self.sound_manager.play_notification()

    def on_ai_finished(self):
        """Завершение генерации ответа"""
        has_response = bool(self.current_ai_response.strip())
        self.tts_btn.setEnabled(has_response)
        if has_response:
            self.tts_btn.setText("🔊")
            self.tts_btn.setToolTip("Озвучить ответ")
        self.sound_manager.play_notification()
        # Очищаем прикрепленные файлы после отправки
        for i in reversed(range(self.attachments_layout.count())):
            widget = self.attachments_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()
        self.attachments.clear()
        self.attachments_scroll.setVisible(False)

    def clear_chat(self):
        """Очистка истории чата"""
        self.user_chat_history.clear()
        self.ai_chat_history.clear()
        self.current_ai_response = ""
        self.tts_btn.setEnabled(False)

    def mousePressEvent(self, event):
        """Перетаскивание окна"""
        if event.button() == Qt.LeftButton:
            self.drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        """Перетаскивание окна"""
        if event.buttons() == Qt.LeftButton and self.drag_pos:
            self.move(self.pos() + event.globalPosition().toPoint() - self.drag_pos)
            self.drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        """Завершение перетаскивания"""
        self.drag_pos = None

    def closeEvent(self, event):
        """Обработка закрытия окна"""
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        self.settings.setValue("chat_accent_color", self.chat_accent_color or "")
        event.accept()

class ConversationModeWindow(QWidget):
    """Разговорный режим — автоматический цикл: слушать → отправить → озвучить.
    compact=True — компактное окно поверх всех окон."""

    def __init__(self, chat_window, compact=False, parent=None):
        super().__init__(parent)
        self.chat_window = chat_window
        self.compact = compact
        self._active = False
        self._cycle_after_tts = False

        flags = Qt.Window | Qt.WindowStaysOnTopHint
        if compact:
            flags |= Qt.FramelessWindowHint
            self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowFlags(flags)

        self.setWindowTitle("Разговорный режим" if not compact else "")
        if compact:
            self.setFixedSize(260, 90)
        else:
            self.setMinimumSize(420, 280)
            self.resize(440, 320)

        self._build_ui()

    # ------------------------------------------------------------------ UI --
    def _build_ui(self):
        layout = QVBoxLayout(self)

        if self.compact:
            layout.setContentsMargins(10, 8, 10, 8)
            layout.setSpacing(5)
            self.setStyleSheet("""
                QWidget {
                    background-color: rgba(30,30,46,220);
                    border-radius: 14px;
                    color: #cdd6f4;
                    font-family: 'Segoe UI', sans-serif;
                }
                QPushButton {
                    background: rgba(89,180,250,180);
                    border: none;
                    border-radius: 8px;
                    color: #1e1e2e;
                    font-weight: bold;
                    padding: 4px 10px;
                }
                QPushButton:hover { background: rgba(137,220,235,200); }
                QPushButton#stopBtn {
                    background: rgba(243,139,168,180);
                    color: #1e1e2e;
                }
            """)
        else:
            layout.setContentsMargins(15, 15, 15, 15)
            layout.setSpacing(8)

        # Status label
        self.status_label = QLabel("● Готов")
        self.status_label.setAlignment(Qt.AlignCenter)
        font = self.status_label.font()
        font.setPointSize(11 if self.compact else 13)
        font.setBold(True)
        self.status_label.setFont(font)
        layout.addWidget(self.status_label)

        # Last recognized text + transcript (hidden in compact)
        if not self.compact:
            self.text_label = QLabel("")
            self.text_label.setWordWrap(True)
            self.text_label.setAlignment(Qt.AlignCenter)
            self.text_label.setStyleSheet("color: #89dceb; font-size: 10pt; font-style: italic;")
            layout.addWidget(self.text_label)

            self.transcript = QTextEdit()
            self.transcript.setReadOnly(True)
            self.transcript.setMaximumHeight(120)
            self.transcript.setPlaceholderText("Здесь появится стенограмма диалога...")
            self.transcript.setStyleSheet(
                "background: rgba(30,30,46,180); color: #cdd6f4; "
                "border: 1px solid #45475a; border-radius: 6px; font-size: 9pt;"
            )
            layout.addWidget(self.transcript)

        # Buttons row
        btn_row = QHBoxLayout()
        self.start_btn = QPushButton("▶  Старт")
        self.start_btn.clicked.connect(self.start_cycle)

        self.stop_btn = QPushButton("■  Стоп")
        self.stop_btn.setObjectName("stopBtn")
        self.stop_btn.clicked.connect(self.stop_cycle)
        self.stop_btn.setEnabled(False)

        close_btn = QPushButton("✕")
        close_btn.setFixedWidth(32)
        close_btn.clicked.connect(self.close)

        btn_row.addWidget(self.start_btn)
        btn_row.addWidget(self.stop_btn)
        if not self.compact:
            clear_btn = QPushButton("🗑")
            clear_btn.setFixedWidth(36)
            clear_btn.setToolTip("Очистить стенограмму")
            clear_btn.clicked.connect(self._clear_transcript)
            btn_row.addWidget(clear_btn)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

        # Drag support for compact mode
        self._drag_pos = None

    # ------------------------------------------------------ drag (compact) --
    def mousePressEvent(self, event):
        if self.compact and event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self.compact and event.buttons() == Qt.LeftButton and self._drag_pos:
            self.move(self.pos() + event.globalPosition().toPoint() - self._drag_pos)
            self._drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    # ----------------------------------------------------------- cycle logic --
    def start_cycle(self):
        self._active = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self._listen()

    def stop_cycle(self):
        self._active = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._set_status("■ Остановлен", "#f38ba8")
        # Stop TTS if playing
        cw = self.chat_window
        if cw.is_speaking and cw.tts_worker:
            cw.tts_worker.stop()

    def _listen(self):
        if not self._active:
            return
        self._set_status("🎤 Слушаю…", "#a6e3a1")
        cw = self.chat_window
        cw.voice_worker = VoiceWorker(mode="recognize")
        cw.voice_worker.speech_recognized.connect(self._on_recognized)
        cw.voice_worker.error_occurred.connect(self._on_listen_error)
        cw.voice_worker.start()

    def _on_recognized(self, text):
        if not self._active:
            return
        if not self.compact:
            self.text_label.setText(f"«{text}»")
            if hasattr(self, "transcript"):
                self.transcript.append(f"<span style='color:#a6e3a1'><b>Вы:</b> {text}</span>")
        self._set_status("⌛ Обрабатываю…", "#89b4fa")
        cw = self.chat_window
        # hook into ai finished to start TTS then listen again
        self._cycle_after_tts = True
        cw.input_field.setText(text)
        # connect once to on_ai_finished to speak & re-listen
        try:
            cw.ollama_worker.finished_signal.disconnect(self._on_ai_done)
        except Exception:
            pass
        cw.send_message()
        # We need to hook after next AI response
        QTimer.singleShot(200, self._hook_ai_worker)

    def _hook_ai_worker(self):
        cw = self.chat_window
        if cw.ollama_worker:
            try:
                cw.ollama_worker.finished_signal.disconnect(self._on_ai_done)
            except Exception:
                pass
            cw.ollama_worker.finished_signal.connect(self._on_ai_done)

    def _on_ai_done(self):
        if not self._active:
            return
        self._set_status("🔊 Озвучиваю…", "#f9e2af")
        cw = self.chat_window
        if cw.current_ai_response.strip() and not self.compact and hasattr(self, "transcript"):
            snippet = cw.current_ai_response.strip()[:120]
            if len(cw.current_ai_response.strip()) > 120:
                snippet += "…"
            self.transcript.append(f"<span style='color:#89dceb'><b>AI:</b> {snippet}</span>")
        if cw.current_ai_response.strip():
            cw.tts_worker = VoiceWorker(mode="synthesize", text=cw.current_ai_response)
            cw.tts_worker.voice_playing.connect(self._on_tts_done)
            cw.tts_worker.error_occurred.connect(lambda e: self._listen())
            cw.is_speaking = True
            cw.tts_worker.start()
        else:
            self._listen()

    def _on_tts_done(self, playing):
        if not playing:
            self.chat_window.is_speaking = False
            if self._active:
                QTimer.singleShot(300, self._listen)

    def _on_listen_error(self, err):
        if not self._active:
            return
        self._set_status(f"⚠ {err[:35]}", "#f38ba8")
        QTimer.singleShot(1500, self._listen)

    def _clear_transcript(self):
        if hasattr(self, "transcript"):
            self.transcript.clear()

    def _set_status(self, text, color="#cdd6f4"):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {color}; font-weight: bold;")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Chat")
    app.setApplicationVersion("2.0")

    window = ChatWindow()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()