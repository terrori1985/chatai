import sys
import os
import subprocess
from datetime import datetime
import platform
from pathlib import Path
import mimetypes
import chardet
import re
import tempfile
import wave
import pyaudio
import speech_recognition as sr
from gtts import gTTS
import pygame
import requests
import json
import time
import threading

from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                              QHBoxLayout, QTextEdit, QLineEdit, QPushButton,
                              QLabel, QComboBox, QMessageBox, QInputDialog,
                              QSlider, QColorDialog, QMenu, QSplitter, QWidgetAction,
                              QDialog, QFileDialog, QScrollArea, QFrame, QCheckBox,
                              QGroupBox, QSpinBox, QProgressBar, QSystemTrayIcon)
from PySide6.QtCore import Qt, QThread, Signal, Slot, QSettings, QUrl, QRegularExpression, QTimer
from PySide6.QtGui import (QPalette, QColor, QTextCursor, QActionGroup, QAction,
                          QFont, QTextCharFormat, QSyntaxHighlighter, QTextDocument,
                          QTextFormat, QGuiApplication, QClipboard, QIcon)
from PySide6.QtMultimedia import QSoundEffect

# --- Вспомогательные классы ---

class VoiceWorker(QThread):
    """Распознавание речи и синтез голоса"""
    speech_recognized = Signal(str)
    error_occurred = Signal(str)
    voice_playing = Signal(bool)

    def __init__(self, mode="recognize", text=None, parent=None):
        super().__init__(parent)
        self.mode = mode  # "recognize" или "synthesize"
        self.text = text
        self._stop_requested = False
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

        # Инициализация pygame для воспроизведения звука
        pygame.mixer.init()

    def stop(self):
        """Остановить воспроизведение"""
        self._stop_requested = True
        if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()

    def run(self):
        try:
            if self.mode == "recognize":
                self.recognize_speech()
            elif self.mode == "synthesize":
                self.synthesize_speech(self.text)
        except Exception as e:
            self.error_occurred.emit(f"Ошибка голосового модуля: {str(e)}")

    def recognize_speech(self):
        """Распознавание речи с микрофона"""
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source)
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=10)

            text = self.recognizer.recognize_google(audio, language="ru-RU")
            self.speech_recognized.emit(text)

        except sr.WaitTimeoutError:
            self.error_occurred.emit("Таймаут: речь не обнаружена")
        except sr.UnknownValueError:
            self.error_occurred.emit("Речь не распознана")
        except sr.RequestError as e:
            self.error_occurred.emit(f"Ошибка сервиса распознавания: {e}")

    def synthesize_speech(self, text):
        """Синтез речи из текста"""
        try:
            # Создаем временный файл для аудио
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
                tts = gTTS(text=text, lang='ru', slow=False)
                tts.save(tmp_file.name)
                tmp_file_path = tmp_file.name

            # Воспроизводим аудио
            self.voice_playing.emit(True)
            pygame.mixer.music.load(tmp_file_path)
            pygame.mixer.music.play()

            # Ждем завершения воспроизведения или остановки
            while pygame.mixer.music.get_busy():
                if self._stop_requested:
                    pygame.mixer.music.stop()
                    break
                QThread.msleep(100)

            self.voice_playing.emit(False)

            # Удаляем временный файл
            try:
                os.unlink(tmp_file_path)
            except Exception:
                pass

        except Exception as e:
            self.error_occurred.emit(f"Ошибка синтеза речи: {str(e)}")
            self.voice_playing.emit(False)

class CodeHighlighter(QSyntaxHighlighter):
    """Подсветка синтаксиса для различных языков программирования"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []

        # Базовые правила для разных языков
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Bold)

        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))

        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))

        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8"))

        # Общие ключевые слова для нескольких языков
        keywords = [
            'break', 'case', 'catch', 'class', 'const', 'continue', 'default',
            'delete', 'do', 'else', 'enum', 'export', 'extends', 'false', 'finally',
            'for', 'function', 'if', 'import', 'in', 'instanceof', 'new', 'null',
            'return', 'super', 'switch', 'this', 'throw', 'true', 'try', 'typeof',
            'var', 'void', 'while', 'with', 'yield'
        ]

        for keyword in keywords:
            pattern = r'\b' + keyword + r'\b'
            self.highlighting_rules.append((QRegularExpression(pattern), keyword_format))

        # Строки
        self.highlighting_rules.append((QRegularExpression(r'\".*?\"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'\'.*?\''), string_format))

        # Комментарии
        self.highlighting_rules.append((QRegularExpression(r'//.*'), comment_format))
        self.highlighting_rules.append((QRegularExpression(r'/\*.*?\*/'), comment_format))

        # Числа
        self.highlighting_rules.append((QRegularExpression(r'\b\d+\b'), number_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

class FileAttachmentWidget(QFrame):
    """Виджет для отображения прикрепленного файла"""
    def __init__(self, file_path, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.setFrameStyle(QFrame.Box)
        self.setStyleSheet("""
            QFrame {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px;
                margin: 2px;
            }
        """)

        layout = QVBoxLayout(self)

        file_name = QLabel(Path(file_path).name)
        file_name.setStyleSheet("font-weight: bold;")

        file_info = QLabel(f"{self.get_file_size()} | {self.get_file_type()}")
        file_info.setStyleSheet("color: #666; font-size: 10px;")

        btn_layout = QHBoxLayout()
        view_btn = QPushButton("Просмотр")
        view_btn.clicked.connect(self.view_file)
        view_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        copy_btn = QPushButton("Копировать")
        copy_btn.clicked.connect(self.copy_content)
        copy_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")

        remove_btn = QPushButton("✕")
        remove_btn.clicked.connect(self.remove_file)
        remove_btn.setStyleSheet("font-size: 10px; padding: 2px 5px;")
        remove_btn.setFixedSize(20, 20)

        btn_layout.addWidget(view_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(remove_btn)

        layout.addWidget(file_name)
        layout.addWidget(file_info)
        layout.addLayout(btn_layout)

        self.setFixedHeight(80)

    def get_file_size(self):
        size = os.path.getsize(self.file_path)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"

    def get_file_type(self):
        mime_type, _ = mimetypes.guess_type(self.file_path)
        if mime_type:
            return mime_type.split('/')[-1].upper()
        return Path(self.file_path).suffix.upper().replace('.', '')

    def view_file(self):
        """Просмотр содержимого файла"""
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Просмотр: {Path(self.file_path).name}")
        dialog.setMinimumSize(800, 600)

        layout = QVBoxLayout(dialog)

        # Текстовое поле для содержимого
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)

        # Загружаем содержимое файла
        try:
            content = self.read_file_content()
            text_edit.setPlainText(content)

            # Включаем подсветку синтаксиса для известных форматов
            if self.is_code_file():
                highlighter = CodeHighlighter(text_edit.document())

        except Exception as e:
            text_edit.setPlainText(f"Ошибка чтения файла: {str(e)}")

        layout.addWidget(text_edit)

        # Кнопки
        btn_layout = QHBoxLayout()
        copy_btn = QPushButton("Копировать всё")
        copy_btn.clicked.connect(lambda: self.copy_to_clipboard(content))
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(dialog.accept)

        btn_layout.addWidget(copy_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)

        layout.addLayout(btn_layout)
        dialog.exec()

    def read_file_content(self):
        """Чтение содержимого файла с определением кодировки"""
        try:
            # Определяем кодировку
            with open(self.file_path, 'rb') as f:
                raw_data = f.read()
                result = chardet.detect(raw_data)
                encoding = result['encoding'] or 'utf-8'

            # Читаем файл в правильной кодировке
            with open(self.file_path, 'r', encoding=encoding, errors='replace') as f:
                return f.read()
        except UnicodeDecodeError:
            # Если не удается декодировать как текст, показываем бинарные данные
            return "Бинарный файл - содержимое не может быть отображено как текст"

    def is_code_file(self):
        """Проверяем, является ли файл кодом"""
        code_extensions = {'.py', '.js', '.java', '.cpp', '.c', '.h', '.html',
                          '.css', '.php', '.rb', '.go', '.rs', '.ts', '.json',
                          '.xml', '.yaml', '.yml', '.sql', '.sh', '.bat', '.ps1'}
        return Path(self.file_path).suffix.lower() in code_extensions

    def copy_content(self):
        """Копирование содержимого файла в буфер обмена"""
        try:
            content = self.read_file_content()
            self.copy_to_clipboard(content)
            QMessageBox.information(self, "Успех", "Содержимое файла скопировано в буфер обмена")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось скопировать файл: {str(e)}")

    def copy_to_clipboard(self, text):
        """Копирование текста в буфер обмена"""
        clipboard = QGuiApplication.clipboard()
        clipboard.setText(text)

    def remove_file(self):
        """Удаление прикрепленного файла"""
        self.deleteLater()

class OllamaWorker(QThread):
    """Отвечает за асинхронный запуск модели Ollama."""
    response_received = Signal(str)
    error_occurred = Signal(str)
    finished_signal = Signal()
    thinking_started = Signal()
    thinking_finished = Signal()

    def __init__(self, model_name, prompt, attachments=None, server_url="http://localhost:11434"):
        super().__init__()
        self.model_name = model_name
        self.prompt = prompt
        self.attachments = attachments or []
        self.server_url = server_url

    def run(self):
        try:
            self.thinking_started.emit()
            
            # Подготавливаем полный промпт с вложениями
            full_prompt = self.prompt

            if self.attachments:
                full_prompt += "\n\n--- ПРИКРЕПЛЕННЫЕ ФАЙЛЫ ---\n"
                for i, attachment in enumerate(self.attachments, 1):
                    try:
                        content = self.read_file_content(attachment)
                        file_name = Path(attachment).name
                        file_extension = Path(attachment).suffix.lower()

                        full_prompt += f"\n--- ФАЙЛ {i}: {file_name} ---\n"
                        full_prompt += f"Расширение: {file_extension}\n"
                        full_prompt += f"Содержимое:\n```{file_extension}\n{content}\n```\n"

                    except Exception as e:
                        full_prompt += f"\n--- ФАЙЛ {i}: {Path(attachment).name} ---\n"
                        full_prompt += f"ОШИБКА ЧТЕНИЯ: {str(e)}\n"

                full_prompt += "\n--- КОНЕЦ ФАЙЛОВ ---\n\n"
                full_prompt += "Проанализируй прикрепленные файлы и ответь на мой запрос с учетом их содержимого.\n"

            # Используем API Ollama вместо subprocess
            headers = {'Content-Type': 'application/json'}
            data = {
                'model': self.model_name,
                'prompt': full_prompt,
                'stream': True
            }

            response = requests.post(
                f"{self.server_url}/api/generate",
                headers=headers,
                json=data,
                stream=True
            )

            if response.status_code != 200:
                self.error_occurred.emit(f"Ошибка API: {response.status_code} - {response.text}")
                return

            full_response = ""
            for line in response.iter_lines():
                if line:
                    try:
                        json_data = json.loads(line)
                        if 'response' in json_data:
                            chunk = json_data['response']
                            full_response += chunk
                            self.response_received.emit(chunk)
                        if json_data.get('done', False):
                            break
                    except json.JSONDecodeError:
                        continue

            self.thinking_finished.emit()
            self.finished_signal.emit()

        except requests.exceptions.ConnectionError:
            self.error_occurred.emit("Не удалось подключиться к серверу Ollama")
            self.finished_signal.emit()
        except requests.exceptions.Timeout:
            self.error_occurred.emit("Таймаут подключения к серверу Ollama")
            self.finished_signal.emit()
        except Exception as e:
            self.error_occurred.emit(f"Ошибка: {str(e)}")
            self.finished_signal.emit()

    def read_file_content(self, file_path):
        """Чтение содержимого файла с обработкой различных кодировок"""
        try:
            with open(file_path, 'rb') as f:
                raw_data = f.read()

            result = chardet.detect(raw_data)
            encoding = result['encoding'] or 'utf-8'

            try:
                content = raw_data.decode(encoding, errors='replace')
                max_file_size = 10000
                if len(content) > max_file_size:
                    content = content[:max_file_size] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"
                return content
            except UnicodeDecodeError:
                for alt_encoding in ['utf-8', 'latin-1', 'cp1251', 'cp1252']:
                    try:
                        content = raw_data.decode(alt_encoding, errors='replace')
                        if len(content) > 10000:
                            content = content[:10000] + f"\n\n[ФАЙЛ ОБРЕЗАН, РАЗМЕР: {len(content)} СИМВОЛОВ]"
                        return content
                    except UnicodeDecodeError:
                        continue
                return f"БИНАРНЫЙ ФАЙЛ. Размер: {len(raw_data)} байт."

        except Exception as e:
            return f"ОШИБКА ЧТЕНИЯ ФАЙЛА: {str(e)}"


class GeminiWorker(QThread):
    """Отправляет запрос к Google Gemini API (streaming через SSE)."""
    response_received = Signal(str)
    error_occurred    = Signal(str)
    finished_signal   = Signal()
    thinking_started  = Signal()
    thinking_finished = Signal()

    GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models"

    def __init__(self, model_name: str, prompt: str, api_key: str,
                 attachments=None, parent=None):
        super().__init__(parent)
        # model_name приходит как "gemini:gemini-1.5-pro" → берём часть после ":"
        self.model_name  = model_name.split(":", 1)[-1] if ":" in model_name else model_name
        self.prompt      = prompt
        self.api_key     = api_key
        self.attachments = attachments or []

    def run(self):
        try:
            self.thinking_started.emit()
            full_prompt = self.prompt
            if self.attachments:
                full_prompt += "\n\n--- ПРИКРЕПЛЕННЫЕ ФАЙЛЫ ---\n"
                for i, path in enumerate(self.attachments, 1):
                    try:
                        content = self._read_file(path)
                        ext = Path(path).suffix.lower()
                        full_prompt += f"\n--- ФАЙЛ {i}: {Path(path).name} ---\n"
                        full_prompt += f"```{ext}\n{content}\n```\n"
                    except Exception as e:
                        full_prompt += f"\n--- ФАЙЛ {i}: {Path(path).name} ---\nОШИБКА: {e}\n"
                full_prompt += "\n--- КОНЕЦ ФАЙЛОВ ---\n"

            url = f"{self.GEMINI_BASE}/{self.model_name}:streamGenerateContent"
            headers = {"Content-Type": "application/json"}
            params  = {"key": self.api_key, "alt": "sse"}
            body    = {"contents": [{"parts": [{"text": full_prompt}]}]}

            resp = requests.post(url, headers=headers, params=params,
                                 json=body, stream=True, timeout=60)
            if resp.status_code != 200:
                self.error_occurred.emit(
                    f"Gemini API {resp.status_code}: {resp.text[:300]}")
                self.finished_signal.emit()
                return

            self.thinking_finished.emit()
            for raw_line in resp.iter_lines():
                if not raw_line:
                    continue
                line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
                if line.startswith("data: "):
                    line = line[6:]
                if line in ("[DONE]", ""):
                    continue
                try:
                    obj = json.loads(line)
                    for cand in obj.get("candidates", []):
                        for part in cand.get("content", {}).get("parts", []):
                            chunk = part.get("text", "")
                            if chunk:
                                self.response_received.emit(chunk)
                except json.JSONDecodeError:
                    continue

            self.finished_signal.emit()
        except Exception as e:
            self.error_occurred.emit(f"Gemini ошибка: {str(e)}")
            self.finished_signal.emit()

    def _read_file(self, file_path):
        with open(file_path, 'rb') as f:
            raw = f.read()
        result = chardet.detect(raw)
        enc = result['encoding'] or 'utf-8'
        content = raw.decode(enc, errors='replace')
        return content[:10000] + ("\n[ОБРЕЗАНО]" if len(content) > 10000 else "")


# ---------------------------------------------------------------------------
# Голосовые команды управления ПК
# ---------------------------------------------------------------------------

# Команды: ключевое слово → действие
VOICE_PC_COMMANDS = {
    # браузер / системные
    "открой браузер":      lambda: subprocess.Popen(["xdg-open", "https://google.com"]),
    "открой терминал":     lambda: subprocess.Popen(["konsole"]),
    "открой файловый менеджер": lambda: subprocess.Popen(["dolphin"]),
    "открой настройки":    lambda: subprocess.Popen(["systemsettings"]),
    # медиа
    "пауза":               lambda: subprocess.run(["playerctl", "pause"]),
    "играть":              lambda: subprocess.run(["playerctl", "play"]),
    "следующий трек":      lambda: subprocess.run(["playerctl", "next"]),
    "предыдущий трек":     lambda: subprocess.run(["playerctl", "previous"]),
    # громкость
    "громче":              lambda: subprocess.run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "+5%"]),
    "тише":                lambda: subprocess.run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "-5%"]),
    "выключить звук":      lambda: subprocess.run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]),
    # окна
    "свернуть окно":       lambda: subprocess.run(["xdotool", "getactivewindow", "windowminimize"]),
    "закрыть окно":        lambda: subprocess.run(["xdotool", "getactivewindow", "key", "alt+F4"]),
    # скриншот
    "скриншот":            lambda: subprocess.Popen(["spectacle", "-b", "-f"]),
    # питание
    "заблокировать экран": lambda: subprocess.run(["loginctl", "lock-session"]),
    "выключить компьютер": lambda: subprocess.run(["shutdown", "-h", "now"]),
    "перезагрузить":       lambda: subprocess.run(["reboot"]),
}


class VoiceCommandWorker(QThread):
    """Непрерывно слушает микрофон в фоне и выполняет голосовые команды ПК.
    Реагирует только если текст начинается с wake-word или содержит ключевую команду."""

    command_detected  = Signal(str)   # текст распознанной команды
    command_executed  = Signal(str)   # название выполненной команды
    status_changed    = Signal(str)   # "listening" / "processing" / "idle" / "error:…"
    error_occurred    = Signal(str)

    def __init__(self, wake_word="компьютер", parent=None):
        super().__init__(parent)
        self.wake_word    = wake_word.lower()
        self._running     = False
        self.recognizer   = sr.Recognizer()

    def start_listening(self):
        self._running = True
        if not self.isRunning():
            self.start()

    def stop_listening(self):
        self._running = False

    def run(self):
        mic = sr.Microphone()
        with mic as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=1)

        while self._running:
            self.status_changed.emit("listening")
            try:
                with mic as source:
                    audio = self.recognizer.listen(source, timeout=4, phrase_time_limit=8)
                self.status_changed.emit("processing")
                text = self.recognizer.recognize_google(audio, language="ru-RU").lower()
                self.command_detected.emit(text)

                # Проверяем wake-word (если задан)
                if self.wake_word and self.wake_word not in text:
                    continue

                # Ищем команду в тексте
                matched = None
                for cmd_key in VOICE_PC_COMMANDS:
                    if cmd_key in text:
                        matched = cmd_key
                        break

                if matched:
                    try:
                        VOICE_PC_COMMANDS[matched]()
                        self.command_executed.emit(matched)
                    except Exception as e:
                        self.error_occurred.emit(f"Ошибка команды '{matched}': {e}")

            except sr.WaitTimeoutError:
                pass
            except sr.UnknownValueError:
                pass
            except sr.RequestError as e:
                self.error_occurred.emit(f"Сервис распознавания: {e}")
                QThread.msleep(2000)
            except Exception as e:
                self.error_occurred.emit(str(e))
                QThread.msleep(1000)

        self.status_changed.emit("idle")


class ModelManager:
    """Управляет списком доступных моделей Ollama и Gemini."""

    GEMINI_MODELS_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models"

    def load_models(self, server_url="http://localhost:11434"):
        models = []
        try:
            response = requests.get(f"{server_url}/api/tags", timeout=10)
            if response.status_code == 200:
                data = response.json()
                for model in data.get('models', []):
                    models.append(model['name'])
        except requests.exceptions.ConnectionError:
            print("Не удалось подключиться к серверу Ollama")
        except Exception as e:
            print(f"Ошибка загрузки моделей: {e}")
        return models

    def load_gemini_models(self, api_key: str):
        """Загружает список доступных Gemini-моделей через Google API."""
        models = []
        try:
            resp = requests.get(
                self.GEMINI_MODELS_ENDPOINT,
                params={"key": api_key},
                timeout=10
            )
            if resp.status_code == 200:
                data = resp.json()
                for m in data.get("models", []):
                    name = m.get("name", "")
                    # фильтруем только генерирующие модели
                    if "generateContent" in m.get("supportedGenerationMethods", []):
                        # name = "models/gemini-1.5-pro" -> "gemini:gemini-1.5-pro"
                        short = name.split("/")[-1]
                        models.append(f"gemini:{short}")
            else:
                print(f"Gemini API error: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            print(f"Ошибка загрузки моделей Gemini: {e}")
        return models

    def check_connection(self, server_url="http://localhost:11434"):
        """Проверка подключения к серверу Ollama"""
        try:
            response = requests.get(f"{server_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False

    def check_gemini_key(self, api_key: str) -> bool:
        """Проверяет валидность Gemini API-ключа."""
        try:
            resp = requests.get(
                self.GEMINI_MODELS_ENDPOINT,
                params={"key": api_key},
                timeout=8
            )
            return resp.status_code == 200
        except:
            return False

class SoundManager:
    """Управляет звуковыми уведомлениями."""
    def __init__(self):
        self.enabled = True
        self.sound_file = ""
        self.sound_effect = QSoundEffect()
        self.load_default_sound()

    def load_default_sound(self):
        """Загрузка звука по умолчанию"""
        default_path = Path("notification.wav")
        if default_path.exists():
            self.set_sound_file(str(default_path))

    def set_enabled(self, enabled):
        """Установить состояние звука"""
        self.enabled = enabled

    def set_sound_file(self, file_path):
        """Установить файл звука"""
        self.sound_file = file_path
        if file_path and Path(file_path).exists():
            self.sound_effect.setSource(QUrl.fromLocalFile(file_path))

    def play_notification(self):
        if self.enabled and self.sound_effect.source().isValid():
            self.sound_effect.play()

class ThemeManager:
    """
    Управляет темами (светлая, темная, кастомная) и генерирует стили.
    """
    def __init__(self):
        self.themes = {
            "Темная": {
                "background": "#1e1e2e", "text": "#cdd6f4", "base": "#181825",
                "accent": "#89b4fa", "user_message": "#a6e3a1", "ai_message": "#89dceb",
                "system_message": "#f38ba8", "border": "#45475a",
                "button": "#585b70", "button_text": "#cdd6f4"
            },
            "Светлая": {
                "background": "#eff1f5", "text": "#4c4f69", "base": "#ffffff",
                "accent": "#1e66f5", "user_message": "#40a02b", "ai_message": "#04a5e5",
                "system_message": "#d20f39", "border": "#dce0e8",
                "button": "#dce0e8", "button_text": "#4c4f69"
            },
            "Пользовательская": {
                "background": "#1e1e2e", "text": "#cdd6f4", "base": "#181825",
                "accent": "#89b4fa", "user_message": "#a6e3a1", "ai_message": "#89dceb",
                "system_message": "#f38ba8", "border": "#45475a",
                "button": "#585b70", "button_text": "#cdd6f4"
            }
        }
        self.custom_colors = {}

    def get_palette_and_style(self, theme_name, background_opacity=100):
        colors = self.themes.get(theme_name, {})
        if theme_name == "Пользовательская":
            colors = {**colors, **self.custom_colors}

        if not colors:
            return QPalette(), "", {}

        bg_color = QColor(colors["background"])
        base_color = QColor(colors["base"])

        if background_opacity < 100:
            bg_alpha = int(255 * (background_opacity / 100.0))
            base_alpha = int(255 * min(1.0, (background_opacity / 100.0) + 0.2))

            bg_color.setAlpha(bg_alpha)
            base_color.setAlpha(base_alpha)

        palette = QPalette()
        palette.setColor(QPalette.Window, bg_color)
        palette.setColor(QPalette.WindowText, QColor(colors["text"]))
        palette.setColor(QPalette.Base, base_color)
        palette.setColor(QPalette.AlternateBase, QColor(colors["border"]))
        palette.setColor(QPalette.Text, QColor(colors["text"]))
        palette.setColor(QPalette.Button, QColor(colors["button"]))
        palette.setColor(QPalette.ButtonText, QColor(colors["button_text"]))
        palette.setColor(QPalette.Highlight, QColor(colors["accent"]))
        palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))

        bg_rgba = f"rgba({bg_color.red()}, {bg_color.green()}, {bg_color.blue()}, {bg_color.alpha()})"
        base_rgba = f"rgba({base_color.red()}, {base_color.green()}, {base_color.blue()}, {base_color.alpha()})"

        stylesheet = f"""
            QMainWindow {{
                background-color: transparent;
                border: none;
            }}
            QWidget#centralWidget {{
                background-color: {bg_rgba};
                border-radius: 12px;
                border: 1px solid {colors["border"]};
            }}
            QTextEdit, QLineEdit, QComboBox {{
                background-color: {base_rgba};
                color: {colors["text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 10px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 10pt;
            }}
            QPushButton {{
                background-color: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {colors['button']},
                    stop:1 {QColor(colors['button']).darker(110).name()}
                );
                color: {colors["button_text"]};
                border: 1px solid {colors["border"]};
                border-radius: 8px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {colors["accent"]};
                color: #ffffff;
                border: 1px solid {colors["accent"]};
            }}
            QSplitter::handle {{
                background-color: {colors["border"]};
            }}
            QSplitter::handle:horizontal {{ width: 1px; }}
            QMenu {{
                background-color: {base_rgba};
                border: 1px solid {colors["border"]};
                color: {colors["text"]};
            }}
            QMenu::item:selected {{
                background-color: {colors["accent"]};
                color: #ffffff;
            }}
            *:focus {{
                border: 1px solid {colors["accent"]};
            }}
        """
        return palette, stylesheet, colors

class SettingsDialog(QDialog):
    """Диалог настроек — вкладки: Сервер | Звук | Gemini | Голосовые команды"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_win = parent
        self.setWindowTitle("Настройки")
        self.setMinimumWidth(560)
        self.setMinimumHeight(460)
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        from PySide6.QtWidgets import QTabWidget
        layout = QVBoxLayout(self)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # ── Вкладка: Сервер Ollama ─────────────────────────────────────────
        server_tab = QWidget()
        sl = QVBoxLayout(server_tab)

        server_group = QGroupBox("Настройки сервера Ollama")
        sg = QVBoxLayout(server_group)
        url_row = QHBoxLayout()
        url_row.addWidget(QLabel("URL сервера:"))
        self.server_url_edit = QLineEdit()
        self.server_url_edit.setPlaceholderText("http://localhost:11434")
        url_row.addWidget(self.server_url_edit)
        sg.addLayout(url_row)
        test_btn = QPushButton("Проверить подключение")
        test_btn.clicked.connect(self.test_connection)
        sg.addWidget(test_btn)
        sl.addWidget(server_group)
        sl.addStretch()
        tabs.addTab(server_tab, "🖥 Ollama")

        # ── Вкладка: Звук ─────────────────────────────────────────────────
        sound_tab = QWidget()
        soundl = QVBoxLayout(sound_tab)
        sound_group = QGroupBox("Настройки звука")
        sg2 = QVBoxLayout(sound_group)
        self.sound_enabled = QCheckBox("Включить звуковые уведомления")
        sg2.addWidget(self.sound_enabled)
        sf_row = QHBoxLayout()
        sf_row.addWidget(QLabel("Файл звука:"))
        self.sound_file_edit = QLineEdit()
        self.sound_file_edit.setReadOnly(True)
        sf_row.addWidget(self.sound_file_edit)
        browse_btn = QPushButton("Обзор...")
        browse_btn.clicked.connect(self.browse_sound_file)
        sf_row.addWidget(browse_btn)
        test_sound_btn = QPushButton("Тест")
        test_sound_btn.clicked.connect(self.test_sound)
        sf_row.addWidget(test_sound_btn)
        sg2.addLayout(sf_row)
        soundl.addWidget(sound_group)
        soundl.addStretch()
        tabs.addTab(sound_tab, "🔔 Звук")

        # ── Вкладка: Gemini API ───────────────────────────────────────────
        gemini_tab = QWidget()
        gl = QVBoxLayout(gemini_tab)

        gemini_group = QGroupBox("Google Gemini API")
        gg = QVBoxLayout(gemini_group)

        key_row = QHBoxLayout()
        key_row.addWidget(QLabel("API ключ:"))
        self.gemini_key_edit = QLineEdit()
        self.gemini_key_edit.setPlaceholderText("AIza…")
        self.gemini_key_edit.setEchoMode(QLineEdit.Password)
        key_row.addWidget(self.gemini_key_edit)
        show_key_btn = QPushButton("👁")
        show_key_btn.setFixedWidth(32)
        show_key_btn.setCheckable(True)
        show_key_btn.toggled.connect(
            lambda on: self.gemini_key_edit.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password))
        key_row.addWidget(show_key_btn)
        gg.addLayout(key_row)

        key_btn_row = QHBoxLayout()
        test_gemini_btn = QPushButton("Проверить ключ")
        test_gemini_btn.clicked.connect(self.test_gemini_key)
        load_models_btn = QPushButton("Загрузить модели Gemini")
        load_models_btn.clicked.connect(self.load_gemini_models)
        key_btn_row.addWidget(test_gemini_btn)
        key_btn_row.addWidget(load_models_btn)
        gg.addLayout(key_btn_row)

        gg.addWidget(QLabel("Доступные модели Gemini:"))
        self.gemini_models_list = QTextEdit()
        self.gemini_models_list.setReadOnly(True)
        self.gemini_models_list.setMaximumHeight(120)
        self.gemini_models_list.setPlaceholderText("Нажмите «Загрузить модели Gemini»…")
        gg.addWidget(self.gemini_models_list)

        self.gemini_enabled = QCheckBox("Добавлять Gemini-модели в список выбора")
        gg.addWidget(self.gemini_enabled)

        gl.addWidget(gemini_group)
        gl.addStretch()
        tabs.addTab(gemini_tab, "✨ Gemini")

        # ── Вкладка: Голосовые команды ────────────────────────────────────
        vc_tab = QWidget()
        vcl = QVBoxLayout(vc_tab)

        vc_group = QGroupBox("Голосовые команды управления ПК")
        vcg = QVBoxLayout(vc_group)

        self.vc_enabled = QCheckBox("Включить голосовые команды")
        vcg.addWidget(self.vc_enabled)

        ww_row = QHBoxLayout()
        ww_row.addWidget(QLabel("Ключевое слово (wake-word):"))
        self.vc_wakeword_edit = QLineEdit()
        self.vc_wakeword_edit.setPlaceholderText("компьютер")
        ww_row.addWidget(self.vc_wakeword_edit)
        vcg.addLayout(ww_row)

        vcg.addWidget(QLabel("Доступные команды:"))
        cmd_list = QTextEdit()
        cmd_list.setReadOnly(True)
        cmd_list.setMaximumHeight(180)
        cmd_list.setStyleSheet("font-family: monospace; font-size: 9pt;")
        lines = []
        for k in VOICE_PC_COMMANDS:
            lines.append(f"  «[wake-word] {k}»")
        cmd_list.setPlainText("\n".join(lines))
        vcg.addWidget(cmd_list)

        note = QLabel(
            "ℹ Команды выполняются только если распознанный текст содержит\n"
            "  ключевое слово (wake-word) И название команды.\n"
            "  Оставьте wake-word пустым, чтобы реагировать без него."
        )
        note.setStyleSheet("color: #888; font-size: 9pt;")
        vcg.addWidget(note)

        vcl.addWidget(vc_group)
        vcl.addStretch()
        tabs.addTab(vc_tab, "🎙 Команды ПК")

        # ── Кнопки ────────────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save_settings)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(save_btn)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)

    # ── helpers ───────────────────────────────────────────────────────────
    def load_settings(self):
        s = QSettings("AI-Chat", "OllamaClientRefactored")
        self.server_url_edit.setText(s.value("server_url", "http://localhost:11434"))
        self.sound_enabled.setChecked(s.value("sound_enabled", True, type=bool))
        self.sound_file_edit.setText(s.value("sound_file", ""))
        self.gemini_key_edit.setText(s.value("gemini_api_key", ""))
        self.gemini_enabled.setChecked(s.value("gemini_enabled", False, type=bool))
        self.vc_enabled.setChecked(s.value("vc_enabled", False, type=bool))
        self.vc_wakeword_edit.setText(s.value("vc_wakeword", "компьютер"))

    def test_connection(self):
        url = self.server_url_edit.text().strip() or "http://localhost:11434"
        if self.parent_win.model_manager.check_connection(url):
            QMessageBox.information(self, "Успех", "Подключение к Ollama установлено!")
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось подключиться к Ollama")

    def browse_sound_file(self):
        fp, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл звука", "", "Audio Files (*.wav *.mp3 *.ogg)")
        if fp:
            self.sound_file_edit.setText(fp)

    def test_sound(self):
        if self.sound_file_edit.text():
            se = QSoundEffect()
            se.setSource(QUrl.fromLocalFile(self.sound_file_edit.text()))
            se.play()

    def test_gemini_key(self):
        key = self.gemini_key_edit.text().strip()
        if not key:
            QMessageBox.warning(self, "Ошибка", "Введите API ключ")
            return
        if self.parent_win.model_manager.check_gemini_key(key):
            QMessageBox.information(self, "Успех", "Gemini API ключ действителен!")
        else:
            QMessageBox.warning(self, "Ошибка",
                                "Ключ недействителен или нет доступа к сети")

    def load_gemini_models(self):
        key = self.gemini_key_edit.text().strip()
        if not key:
            QMessageBox.warning(self, "Ошибка", "Сначала введите API ключ")
            return
        models = self.parent_win.model_manager.load_gemini_models(key)
        if models:
            self.gemini_models_list.setPlainText("\n".join(models))
        else:
            self.gemini_models_list.setPlainText("Модели не найдены или ошибка ключа")

    def save_settings(self):
        s = QSettings("AI-Chat", "OllamaClientRefactored")
        s.setValue("server_url", self.server_url_edit.text())
        s.setValue("sound_enabled", self.sound_enabled.isChecked())
        s.setValue("sound_file", self.sound_file_edit.text())
        s.setValue("gemini_api_key", self.gemini_key_edit.text().strip())
        s.setValue("gemini_enabled", self.gemini_enabled.isChecked())
        s.setValue("vc_enabled", self.vc_enabled.isChecked())
        s.setValue("vc_wakeword", self.vc_wakeword_edit.text().strip())
        self.parent_win.load_settings()
        self.accept()


class CustomThemeDialog(QDialog):
    """Диалог настройки пользовательской темы"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("Настройка пользовательской темы")
        self.setMinimumWidth(400)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)
        
        colors = self.parent.theme_manager.themes["Пользовательская"]
        self.color_buttons = {}
        
        for color_name, color_value in colors.items():
            row_layout = QHBoxLayout()
            label = QLabel(color_name)
            color_btn = QPushButton()
            color_btn.setFixedSize(60, 30)
            color_btn.setStyleSheet(f"background-color: {color_value}; border: 1px solid #ccc;")
            color_btn.clicked.connect(lambda checked, name=color_name: self.choose_color(name))
            
            row_layout.addWidget(label, 1)
            row_layout.addWidget(color_btn)
            scroll_layout.addLayout(row_layout)
            self.color_buttons[color_name] = color_btn
        
        scroll.setWidget(scroll_widget)
        layout.addWidget(scroll)
        
        button_layout = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save_theme)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(save_btn)
        button_layout.addStretch()
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)

    def choose_color(self, color_name):
        color = QColorDialog.getColor()
        if color.isValid():
            self.parent.theme_manager.custom_colors[color_name] = color.name()
            self.color_buttons[color_name].setStyleSheet(f"background-color: {color.name()}; border: 1px solid #ccc;")

    def save_theme(self):
        self.parent.settings.setValue("theme", "Пользовательская")
        self.parent.change_theme("Пользовательская")
        self.accept()

class ChatWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.theme_manager = ThemeManager()
        self.model_manager = ModelManager()
        self.sound_manager = SoundManager()
        self.settings = QSettings("AI-Chat", "OllamaClientRefactored")

        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.current_ai_response = ""
        self.drag_pos = None
        self.background_opacity = 100
        self.attachments = []
        self.is_listening = False
        self.is_speaking = False
        self.server_url = "http://localhost:11434"
        self.connection_status = False
        self.tts_worker = None
        self.ollama_worker = None
        self.chat_accent_color = None
        # Gemini
        self.gemini_api_key = ""
        self.gemini_enabled = False
        # Голосовые команды
        self.vc_worker: VoiceCommandWorker | None = None
        self.vc_enabled = False
        # Компактный виджет
        self._compact_widget: "CompactWidget | None" = None

        self.init_ui()
        self._init_tray()
        self.load_settings()

        self.connection_timer = QTimer()
        self.connection_timer.timeout.connect(self.check_connection_status)
        self.connection_timer.start(5000)
        self.check_connection_status()

    def init_ui(self):
        """Компактный интерфейс с разделением истории"""
        self.setWindowTitle("AI Chat")
        self.setGeometry(100, 100, 1200, 800)

        self.central_widget = QWidget()
        self.central_widget.setObjectName("centralWidget")
        self.setCentralWidget(self.central_widget)

        main_layout = QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(10)

        # --- Верхняя панель управления ---
        top_bar_layout = QHBoxLayout()
        
        # Индикатор подключения
        self.connection_indicator = QLabel("●")
        self.connection_indicator.setFixedWidth(20)
        self.connection_indicator.setAlignment(Qt.AlignCenter)
        
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(35)
        
        refresh_btn = QPushButton("Обновить")
        refresh_btn.clicked.connect(self.refresh_models)
        
        download_btn = QPushButton("Загрузить модель")
        download_btn.clicked.connect(self.download_model)
        
        settings_btn = QPushButton("⚙️")
        settings_btn.setFixedSize(30, 30)
        settings_btn.clicked.connect(self.show_settings)
        settings_btn.setToolTip("Настройки")

        # Кнопки управления окном
        minimize_btn = QPushButton("—")
        minimize_btn.setFixedSize(30, 30)
        minimize_btn.clicked.connect(self.showMinimized)
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.clicked.connect(self.close)

        top_bar_layout.addWidget(self.connection_indicator)
        top_bar_layout.addWidget(QLabel("Модель:"))
        top_bar_layout.addWidget(self.model_combo, 1)
        top_bar_layout.addWidget(refresh_btn)
        top_bar_layout.addWidget(download_btn)
        top_bar_layout.addWidget(settings_btn)

        # Кнопка компактного виджета
        compact_widget_btn = QPushButton("⊞")
        compact_widget_btn.setFixedSize(30, 30)
        compact_widget_btn.setToolTip("Компактный виджет")
        compact_widget_btn.clicked.connect(self.toggle_compact_widget)
        top_bar_layout.addWidget(compact_widget_btn)

        # Индикатор голосовых команд
        self.vc_indicator = QLabel("🎙")
        self.vc_indicator.setFixedWidth(24)
        self.vc_indicator.setAlignment(Qt.AlignCenter)
        self.vc_indicator.setToolTip("Голосовые команды неактивны")
        self.vc_indicator.setStyleSheet("color: #555;")
        top_bar_layout.addWidget(self.vc_indicator)

        top_bar_layout.addStretch()
        top_bar_layout.addWidget(minimize_btn)
        top_bar_layout.addWidget(close_btn)

        # --- Индикатор мышления ---
        self.thinking_indicator = QProgressBar()
        self.thinking_indicator.setRange(0, 0)  # Бесконечная анимация
        self.thinking_indicator.setVisible(False)
        self.thinking_indicator.setFixedHeight(3)
        self.thinking_indicator.setTextVisible(False)

        # --- Область прикрепленных файлов ---
        self.attachments_scroll = QScrollArea()
        self.attachments_scroll.setMaximumHeight(100)
        self.attachments_scroll.setWidgetResizable(True)
        self.attachments_widget = QWidget()
        self.attachments_layout = QHBoxLayout(self.attachments_widget)
        self.attachments_layout.setContentsMargins(5, 5, 5, 5)
        self.attachments_scroll.setWidget(self.attachments_widget)
        self.attachments_scroll.setVisible(False)

        # --- Разделенная область чатов ---
        chat_splitter = QSplitter(Qt.Horizontal)

        user_widget = QWidget()
        user_layout = QVBoxLayout(user_widget)
        user_layout.setContentsMargins(0, 0, 0, 0)
        user_label = QLabel("Ваши сообщения")
        user_label.setAlignment(Qt.AlignCenter)
        user_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.user_chat_history = QTextEdit()
        self.user_chat_history.setReadOnly(True)
        self.user_chat_history.setPlaceholderText("Введите сообщение...")
        # Убираем фон у текста в чате
        self.user_chat_history.setStyleSheet("background-color: transparent; border: none;")
        user_layout.addWidget(user_label)
        user_layout.addWidget(self.user_chat_history)

        ai_widget = QWidget()
        ai_layout = QVBoxLayout(ai_widget)
        ai_layout.setContentsMargins(0, 0, 0, 0)
        ai_label = QLabel("Ответы модели")
        ai_label.setAlignment(Qt.AlignCenter)
        ai_label.setStyleSheet("font-weight: bold; padding: 5px;")
        self.ai_chat_history = QTextEdit()
        self.ai_chat_history.setReadOnly(True)
        self.ai_chat_history.setPlaceholderText("Здесь появятся ответы...")
        # Убираем фон у текста в чате
        self.ai_chat_history.setStyleSheet("background-color: transparent; border: none;")
        ai_layout.addWidget(ai_label)
        ai_layout.addWidget(self.ai_chat_history)

        chat_splitter.addWidget(user_widget)
        chat_splitter.addWidget(ai_widget)
        chat_splitter.setSizes([self.width() // 2, self.width() // 2])

        # --- Поле ввода и кнопки ---
        input_layout = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Введите ваше сообщение...")
        self.input_field.returnPressed.connect(self.send_message)
        self.input_field.setMinimumHeight(40)

        # Кнопка прикрепления файлов
        attach_btn = QPushButton("📎")
        attach_btn.setFixedSize(40, 40)
        attach_btn.clicked.connect(self.attach_files)
        attach_btn.setToolTip("Прикрепить файлы")

        # Кнопка голосового ввода
        self.voice_btn = QPushButton("🎤")
        self.voice_btn.setFixedSize(40, 40)
        self.voice_btn.clicked.connect(self.toggle_voice_input)
        self.voice_btn.setToolTip("Голосовой ввод")
        self.voice_btn.setCheckable(True)

        # Кнопка озвучивания / остановки озвучки
        self.tts_btn = QPushButton("🔊")
        self.tts_btn.setFixedSize(40, 40)
        self.tts_btn.clicked.connect(self.toggle_tts)
        self.tts_btn.setToolTip("Озвучить ответ")
        self.tts_btn.setEnabled(False)

        send_btn = QPushButton("Отправить")
        send_btn.clicked.connect(self.send_message)
        send_btn.setMinimumHeight(40)

        # Кнопка разговорного режима
        self.conv_btn = QPushButton("💬")
        self.conv_btn.setFixedSize(40, 40)
        self.conv_btn.setToolTip("Разговорный режим")
        self.conv_btn.clicked.connect(self.open_conversation_mode)

        # Кнопка компактного разговорного режима
        self.conv_compact_btn = QPushButton("🗨")
        self.conv_compact_btn.setFixedSize(40, 40)
        self.conv_compact_btn.setToolTip("Компактный разговорный режим")
        self.conv_compact_btn.clicked.connect(self.open_conversation_mode_compact)

        # Кнопка акцентного цвета текста чата
        self.accent_color_btn = QPushButton("🎨")
        self.accent_color_btn.setFixedSize(40, 40)
        self.accent_color_btn.setToolTip("Акцентный цвет текста в чате")
        self.accent_color_btn.clicked.connect(self.choose_chat_accent_color)

        input_layout.addWidget(attach_btn)
        input_layout.addWidget(self.voice_btn)
        input_layout.addWidget(self.accent_color_btn)
        input_layout.addWidget(self.conv_btn)
        input_layout.addWidget(self.conv_compact_btn)
        input_layout.addWidget(self.input_field, 1)
        input_layout.addWidget(self.tts_btn)
        input_layout.addWidget(send_btn)

        main_layout.addLayout(top_bar_layout)
        main_layout.addWidget(self.thinking_indicator)
        main_layout.addWidget(self.attachments_scroll)
        main_layout.addWidget(chat_splitter, 1)
        main_layout.addLayout(input_layout)

        # Включаем контекстное меню
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

        # Таймер для анимации кнопки голосового ввода
        self.voice_timer = QTimer()
        self.voice_timer.timeout.connect(self.update_voice_button)

    def load_settings(self):
        """Загрузка настроек из реестра/файла"""
        self.server_url = self.settings.value("server_url", "http://localhost:11434")
        self.sound_manager.set_enabled(self.settings.value("sound_enabled", True, type=bool))
        sound_file = self.settings.value("sound_file", "")
        if sound_file:
            self.sound_manager.set_sound_file(sound_file)

        self.background_opacity = self.settings.value("background_opacity", 100, type=int)
        saved_accent = self.settings.value("chat_accent_color", "")
        if saved_accent:
            self.chat_accent_color = saved_accent
            self.accent_color_btn.setStyleSheet(
                f"background-color: {saved_accent}; border-radius: 8px;"
            )
            self.accent_color_btn.setToolTip(f"Акцентный цвет: {saved_accent}")

        # Gemini
        self.gemini_api_key = self.settings.value("gemini_api_key", "")
        self.gemini_enabled = self.settings.value("gemini_enabled", False, type=bool)

        # Голосовые команды
        vc_on = self.settings.value("vc_enabled", False, type=bool)
        ww    = self.settings.value("vc_wakeword", "компьютер")
        self._apply_voice_commands(vc_on, ww)

        theme = self.settings.value("theme", "Темная")
        self.change_theme(theme)

    def show_settings(self):
        """Показать диалог настроек"""
        dialog = SettingsDialog(self)
        dialog.exec()

    def show_context_menu(self, pos):
        context_menu = QMenu(self)

        # Акцентный цвет текста чата
        accent_action = context_menu.addAction("🖌 Цвет текста ответов...")
        accent_action.triggered.connect(self.choose_chat_accent_color)
        if self.chat_accent_color:
            reset_accent_action = context_menu.addAction("↺ Сбросить цвет текста")
            reset_accent_action.triggered.connect(self._reset_chat_accent_color)
        context_menu.addSeparator()

        # Подменю тем
        theme_menu = context_menu.addMenu("🎨 Тема")
        theme_group = QActionGroup(self)

        for theme_name in self.theme_manager.themes.keys():
            action = QAction(theme_name, self)
            action.setCheckable(True)
            action.setChecked(theme_name == self.settings.value("theme", "Темная"))
            action.triggered.connect(lambda checked, name=theme_name: self.change_theme(name))
            theme_group.addAction(action)
            theme_menu.addAction(action)

        custom_theme_action = QAction("Пользовательская...", self)
        custom_theme_action.triggered.connect(self.customize_theme)
        theme_menu.addAction(custom_theme_action)

        # Настройки прозрачности
        opacity_menu = context_menu.addMenu("🔍 Прозрачность")
        for opacity in [100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 0]:
            action = QAction(f"{opacity}%", self)
            action.triggered.connect(lambda checked, o=opacity: self.set_background_opacity(o))
            opacity_menu.addAction(action)

        # Звуковые уведомления
        sound_action = QAction("🔊 Звуковые уведомления", self)
        sound_action.setCheckable(True)
        sound_action.setChecked(self.settings.value("sound_enabled", True, type=bool))
        sound_action.triggered.connect(self.sound_manager.set_enabled)
        context_menu.addAction(sound_action)

        context_menu.addSeparator()

        # Очистка чата
        clear_action = QAction("🗑️ Очистить чат", self)
        clear_action.triggered.connect(self.clear_chat)
        context_menu.addAction(clear_action)

        context_menu.exec(self.mapToGlobal(pos))

    def customize_theme(self):
        """Настройка пользовательской темы"""
        dialog = CustomThemeDialog(self)
        dialog.exec()

    def change_theme(self, theme_name):
        self.settings.setValue("theme", theme_name)
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(theme_name, self.background_opacity)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def set_background_opacity(self, value):
        self.background_opacity = value
        self.settings.setValue("background_opacity", value)
        current_theme = self.settings.value("theme", "Темная")
        palette, stylesheet, _ = self.theme_manager.get_palette_and_style(current_theme, value)
        QApplication.setPalette(palette)
        self.central_widget.setStyleSheet(stylesheet)

    def check_connection_status(self):
        """Проверка статуса подключения к серверу Ollama"""
        new_status = self.model_manager.check_connection(self.server_url)
        if new_status != self.connection_status:
            self.connection_status = new_status
            self.update_connection_indicator()
            
        if new_status and not self.model_combo.count():
            self.refresh_models()

    def update_connection_indicator(self):
        """Обновление индикатора подключения"""
        if self.connection_status:
            self.connection_indicator.setText("●")
            self.connection_indicator.setStyleSheet("color: green; font-weight: bold;")
            self.connection_indicator.setToolTip("Подключено к серверу Ollama")
        else:
            self.connection_indicator.setText("●")
            self.connection_indicator.setStyleSheet("color: red; font-weight: bold;")
            self.connection_indicator.setToolTip("Нет подключения к серверу Ollama")

    def refresh_models(self):
        """Обновление списка моделей (Ollama + Gemini если включено)"""
        self.model_combo.clear()
        models = self.model_manager.load_models(self.server_url)
        if self.gemini_enabled and self.gemini_api_key:
            gemini_models = self.model_manager.load_gemini_models(self.gemini_api_key)
            models.extend(gemini_models)
        if models:
            self.model_combo.addItems(models)
            # Визуально выделяем Gemini-модели в комбобоксе
            for i in range(self.model_combo.count()):
                if self.model_combo.itemText(i).startswith("gemini:"):
                    self.model_combo.setItemData(
                        i, QColor("#f9e2af"), Qt.ForegroundRole)
        else:
            self.model_combo.addItem("Нет доступных моделей")

    def download_model(self):
        """Диалог загрузки новой модели"""
        model_name, ok = QInputDialog.getText(
            self, "Загрузка модели", "Введите название модели для загрузки:"
        )
        if ok and model_name:
            try:
                # Запускаем процесс загрузки в отдельном потоке
                subprocess.Popen([
                    "ollama", "pull", model_name.strip()
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                QMessageBox.information(
                    self, "Загрузка начата",
                    f"Модель '{model_name}' начала загружаться.\n"
                    f"Проверьте консоль для отслеживания прогресса."
                )
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось начать загрузку: {str(e)}")

    def attach_files(self):
        """Прикрепление файлов"""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self, "Выберите файлы для прикрепления", "", "Все файлы (*)"
        )
        for file_path in file_paths:
            if file_path not in self.attachments:
                self.attachments.append(file_path)
                widget = FileAttachmentWidget(file_path)
                widget.destroyed.connect(lambda: self.remove_attachment(file_path))
                self.attachments_layout.addWidget(widget)

        if self.attachments:
            self.attachments_scroll.setVisible(True)

    def remove_attachment(self, file_path):
        """Удаление прикрепленного файла"""
        if file_path in self.attachments:
            self.attachments.remove(file_path)
        if not self.attachments:
            self.attachments_scroll.setVisible(False)

    def toggle_voice_input(self):
        """Переключение голосового ввода"""
        if self.is_listening:
            self.stop_voice_input()
        else:
            self.start_voice_input()

    def start_voice_input(self):
        """Начало голосового ввода"""
        self.is_listening = True
        self.voice_btn.setChecked(True)
        self.voice_btn.setStyleSheet("background-color: #ff4444;")
        self.voice_btn.setToolTip("Остановить запись")

        self.voice_worker = VoiceWorker(mode="recognize")
        self.voice_worker.speech_recognized.connect(self.on_speech_recognized)
        self.voice_worker.error_occurred.connect(self.on_voice_error)
        self.voice_worker.start()

    def stop_voice_input(self):
        """Остановка голосового ввода"""
        self.is_listening = False
        self.voice_btn.setChecked(False)
        self.voice_btn.setStyleSheet("")
        self.voice_btn.setToolTip("Голосовой ввод")

    def update_voice_button(self):
        """Анимация кнопки голосового ввода"""
        if self.is_listening:
            current_style = self.voice_btn.styleSheet()
            if "background-color: #ff4444" in current_style:
                self.voice_btn.setStyleSheet("background-color: #ff8888; color: white;")
            else:
                self.voice_btn.setStyleSheet("background-color: #ff4444; color: white;")

    def on_speech_recognized(self, text):
        """Обработка распознанной речи"""
        self.input_field.setText(text)
        self.stop_voice_input()
        self.send_message()

    def on_voice_error(self, error_message):
        """Обработка ошибок голосового ввода"""
        self.stop_voice_input()
        QMessageBox.warning(self, "Ошибка голосового ввода", error_message)

    def toggle_tts(self):
        """Озвучить / остановить озвучку"""
        if self.is_speaking:
            self.stop_tts()
        else:
            self.speak_response()

    def speak_response(self):
        """Озвучивание ответа AI"""
        if not self.current_ai_response.strip():
            QMessageBox.warning(self, "Внимание", "Нет ответа для озвучивания")
            return

        if self.is_speaking:
            return

        self.is_speaking = True
        self.tts_btn.setText("⏹")
        self.tts_btn.setToolTip("Остановить озвучку")
        self.tts_btn.setStyleSheet("background-color: #44ff44; color: white;")

        self.tts_worker = VoiceWorker(mode="synthesize", text=self.current_ai_response)
        self.tts_worker.voice_playing.connect(self.on_voice_playing)
        self.tts_worker.error_occurred.connect(self.on_tts_error)
        self.tts_worker.start()

    def stop_tts(self):
        """Остановить воспроизведение"""
        if self.tts_worker:
            self.tts_worker.stop()

    def on_voice_playing(self, playing):
        """Обработка состояния воспроизведения"""
        self.is_speaking = playing
        if not playing:
            self.tts_btn.setText("🔊")
            self.tts_btn.setToolTip("Озвучить ответ")
            self.tts_btn.setStyleSheet("")

    def on_tts_error(self, error_message):
        """Обработка ошибок синтеза речи"""
        self.is_speaking = False
        self.tts_btn.setText("🔊")
        self.tts_btn.setToolTip("Озвучить ответ")
        self.tts_btn.setStyleSheet("")
        self.tts_btn.setEnabled(True)
        QMessageBox.warning(self, "Ошибка синтеза речи", error_message)

    def choose_chat_accent_color(self):
        """Выбор акцентного цвета текста в чате"""
        color = QColorDialog.getColor(
            QColor(self.chat_accent_color) if self.chat_accent_color else QColor("#89dceb"),
            self, "Акцентный цвет текста в чате"
        )
        if color.isValid():
            self.chat_accent_color = color.name()
            self.accent_color_btn.setToolTip(f"Акцентный цвет: {self.chat_accent_color}")
            self.accent_color_btn.setStyleSheet(
                f"background-color: {self.chat_accent_color}; border-radius: 8px;"
            )
        # Если пользователь отменил — ничего не меняем

    def _reset_chat_accent_color(self):
        """Сбросить акцентный цвет к цвету темы"""
        self.chat_accent_color = None
        self.accent_color_btn.setStyleSheet("")
        self.accent_color_btn.setToolTip("Акцентный цвет текста в чате")

    def _get_ai_color(self):
        """Возвращает текущий цвет текста ответов AI"""
        if self.chat_accent_color:
            return self.chat_accent_color
        current_theme = self.settings.value("theme", "Темная")
        return self.theme_manager.themes.get(current_theme, {}).get("ai_message", "#89dceb")

    def open_conversation_mode(self):
        """Открыть разговорный режим"""
        self._conv_window = ConversationModeWindow(self, compact=False)
        self._conv_window.show()

    def open_conversation_mode_compact(self):
        """Открыть компактный разговорный режим"""
        self._conv_compact_window = ConversationModeWindow(self, compact=True)
        screen = QApplication.primaryScreen().availableGeometry()
        self._conv_compact_window.move(screen.right() - 280, screen.bottom() - 110)
        self._conv_compact_window.show()

    def send_message(self):
        """Отправка сообщения"""
        user_message = self.input_field.text().strip()
        if not user_message and not self.attachments:
            return

        selected_model = self.model_combo.currentText()
        if selected_model == "Нет доступных моделей":
            QMessageBox.warning(self, "Ошибка", "Нет доступных моделей для использования")
            return

        # Добавляем сообщение пользователя в историю
        timestamp = datetime.now().strftime("%H:%M:%S")
        current_theme = self.settings.value("theme", "Темная")
        user_color = self.theme_manager.themes.get(current_theme, {}).get("user_message", "#a6e3a1")
        user_message_html = f"""
        <div style='color: {user_color}; padding: 5px;'>
            <strong>Вы ({timestamp}):</strong><br>{user_message}
        </div>
        """
        self.user_chat_history.append(user_message_html)

        if self.attachments:
            files_info = "<br>".join([f"📎 {Path(f).name}" for f in self.attachments])
            self.user_chat_history.append(f"""
            <div style='color: #f9c74f; padding: 5px;'>
                <strong>Прикрепленные файлы:</strong><br>{files_info}
            </div>
            """)

        self.input_field.clear()
        self.current_ai_response = ""
        self.ai_chat_history.clear()

        # Запускаем обработку AI — роутим на Gemini или Ollama
        if selected_model.startswith("gemini:"):
            if not self.gemini_api_key:
                QMessageBox.warning(self, "Ошибка",
                    "Введите Gemini API ключ в Настройки → ✨ Gemini")
                return
            self.ollama_worker = GeminiWorker(
                model_name=selected_model,
                prompt=user_message,
                api_key=self.gemini_api_key,
                attachments=self.attachments,
            )
        else:
            self.ollama_worker = OllamaWorker(
                model_name=selected_model,
                prompt=user_message,
                attachments=self.attachments,
                server_url=self.server_url,
            )
        self.ollama_worker.response_received.connect(self.on_ai_response)
        self.ollama_worker.error_occurred.connect(self.on_ai_error)
        self.ollama_worker.finished_signal.connect(self.on_ai_finished)
        self.ollama_worker.thinking_started.connect(self.on_thinking_started)
        self.ollama_worker.thinking_finished.connect(self.on_thinking_finished)
        self.ollama_worker.start()

    def on_thinking_started(self):
        """Начало обработки модели"""
        self.thinking_indicator.setVisible(True)
        self.tts_btn.setEnabled(False)

    def on_thinking_finished(self):
        """Завершение обработки модели"""
        self.thinking_indicator.setVisible(False)

    def on_ai_response(self, chunk):
        """Обработка ответа AI по частям"""
        self.current_ai_response += chunk
        # Обновляем ответ в реальном времени
        timestamp = datetime.now().strftime("%H:%M:%S")
        ai_color = self._get_ai_color()
        ai_message_html = f"""
        <div style='color: {ai_color}; padding: 5px;'>
            <strong>AI ({timestamp}):</strong><br>{self.current_ai_response}
        </div>
        """
        # Сохраняем позицию скролла
        scrollbar = self.ai_chat_history.verticalScrollBar()
        at_bottom = scrollbar.value() == scrollbar.maximum()
        
        # Обновляем содержимое
        self.ai_chat_history.clear()
        self.ai_chat_history.append(ai_message_html)
        
        # Восстанавливаем позицию скролла
        if at_bottom:
            scrollbar.setValue(scrollbar.maximum())

    def on_ai_error(self, error_msg):
        """Обработка ошибок AI"""
        self.thinking_indicator.setVisible(False)
        timestamp = datetime.now().strftime("%H:%M:%S")
        err_theme = self.settings.value("theme", "Темная")
        err_color = self.theme_manager.themes.get(err_theme, {}).get("system_message", "#f38ba8")
        error_html = f"""
        <div style='color: {err_color}; padding: 5px;'>
            <strong>Ошибка ({timestamp}):</strong><br>{error_msg}
        </div>
        """
        self.ai_chat_history.append(error_html)
        self.sound_manager.play_notification()

    def on_ai_finished(self):
        """Завершение генерации ответа"""
        has_response = bool(self.current_ai_response.strip())
        self.tts_btn.setEnabled(has_response)
        if has_response:
            self.tts_btn.setText("🔊")
            self.tts_btn.setToolTip("Озвучить ответ")
        self.sound_manager.play_notification()
        # Очищаем прикрепленные файлы после отправки
        for i in reversed(range(self.attachments_layout.count())):
            widget = self.attachments_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()
        self.attachments.clear()
        self.attachments_scroll.setVisible(False)

    def clear_chat(self):
        """Очистка истории чата"""
        self.user_chat_history.clear()
        self.ai_chat_history.clear()
        self.current_ai_response = ""
        self.tts_btn.setEnabled(False)

    def mousePressEvent(self, event):
        """Перетаскивание окна"""
        if event.button() == Qt.LeftButton:
            self.drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        """Перетаскивание окна"""
        if event.buttons() == Qt.LeftButton and self.drag_pos:
            self.move(self.pos() + event.globalPosition().toPoint() - self.drag_pos)
            self.drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        """Завершение перетаскивания"""
        self.drag_pos = None

    def closeEvent(self, event):
        """Скрывать в трей вместо закрытия (закрыть через трей → Выход)"""
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        self.settings.setValue("chat_accent_color", self.chat_accent_color or "")
        # Останавливаем голосовые команды при закрытии
        if self.vc_worker:
            self.vc_worker.stop_listening()
        if self._tray and self._tray.isVisible():
            self.hide()
            event.ignore()
        else:
            event.accept()

    def _real_quit(self):
        """Полный выход из приложения (из трея)"""
        if self.vc_worker:
            self.vc_worker.stop_listening()
        if self._compact_widget:
            self._compact_widget.close()
        QApplication.quit()

    # ── Системный трей ────────────────────────────────────────────────────

    def _init_tray(self):
        """Инициализация иконки в системном трее (KDE Plasma / любой DE)."""
        self._tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return

        self._tray = QSystemTrayIcon(self)
        # Попытка использовать системную иконку; при неудаче — генерируем сами
        icon = QIcon.fromTheme("dialog-information")
        if icon.isNull():
            from PySide6.QtGui import QPixmap, QPainter
            pix = QPixmap(32, 32)
            pix.fill(QColor("#89b4fa"))
            p = QPainter(pix)
            p.setPen(QColor("#1e1e2e"))
            p.setFont(QFont("Segoe UI", 10, QFont.Bold))
            p.drawText(pix.rect(), Qt.AlignCenter, "AI")
            p.end()
            icon = QIcon(pix)
        self._tray.setIcon(icon)
        self._tray.setToolTip("AI Chat — работает в фоне")

        tray_menu = QMenu()

        show_action = QAction("📂 Показать окно", self)
        show_action.triggered.connect(self._show_from_tray)
        tray_menu.addAction(show_action)

        compact_action = QAction("⊞ Компактный виджет", self)
        compact_action.triggered.connect(self.toggle_compact_widget)
        tray_menu.addAction(compact_action)

        tray_menu.addSeparator()

        vc_action = QAction("🎙 Голосовые команды", self)
        vc_action.setCheckable(True)
        vc_action.setChecked(self.vc_enabled)
        vc_action.triggered.connect(self._toggle_vc_from_tray)
        tray_menu.addAction(vc_action)
        self._tray_vc_action = vc_action

        tray_menu.addSeparator()

        quit_action = QAction("✕ Выход", self)
        quit_action.triggered.connect(self._real_quit)
        tray_menu.addAction(quit_action)

        self._tray.setContextMenu(tray_menu)
        self._tray.activated.connect(self._on_tray_activated)
        self._tray.show()

    def _show_from_tray(self):
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def _on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.isVisible():
                self.hide()
            else:
                self._show_from_tray()

    def _toggle_vc_from_tray(self, checked: bool):
        ww = self.settings.value("vc_wakeword", "компьютер")
        self._apply_voice_commands(checked, ww)

    # ── Голосовые команды ─────────────────────────────────────────────────

    def _apply_voice_commands(self, enable: bool, wake_word: str):
        """Запустить / остановить VoiceCommandWorker."""
        self.vc_enabled = enable
        if enable:
            if self.vc_worker and self.vc_worker.isRunning():
                self.vc_worker.stop_listening()
                self.vc_worker.wait(500)
            self.vc_worker = VoiceCommandWorker(wake_word=wake_word)
            self.vc_worker.command_detected.connect(self._on_vc_detected)
            self.vc_worker.command_executed.connect(self._on_vc_executed)
            self.vc_worker.status_changed.connect(self._on_vc_status)
            self.vc_worker.error_occurred.connect(self._on_vc_error)
            self.vc_worker.start_listening()
            self.vc_indicator.setStyleSheet("color: #a6e3a1; font-size: 13pt;")
            self.vc_indicator.setToolTip(
                f"Голосовые команды активны (wake-word: «{wake_word or 'нет'}»)")
        else:
            if self.vc_worker:
                self.vc_worker.stop_listening()
            self.vc_indicator.setStyleSheet("color: #555;")
            self.vc_indicator.setToolTip("Голосовые команды неактивны")
        if hasattr(self, "_tray_vc_action"):
            self._tray_vc_action.setChecked(enable)

    def _on_vc_detected(self, text: str):
        # Показываем услышанное в строке состояния (если есть) — тихо
        pass

    def _on_vc_executed(self, cmd: str):
        if self._tray:
            self._tray.showMessage(
                "Голосовая команда",
                f"Выполнено: «{cmd}»",
                QSystemTrayIcon.MessageIcon.Information, 2500)

    def _on_vc_status(self, status: str):
        colors = {
            "listening":   "#a6e3a1",
            "processing":  "#f9e2af",
            "idle":        "#555",
        }
        self.vc_indicator.setStyleSheet(
            f"color: {colors.get(status, '#555')}; font-size: 13pt;")

    def _on_vc_error(self, err: str):
        # Не выводим диалог — только логируем в vc_indicator tooltip
        self.vc_indicator.setToolTip(f"Ошибка голосовых команд: {err}")

    # ── Компактный виджет ─────────────────────────────────────────────────

    def toggle_compact_widget(self):
        """Показать / скрыть компактный виджет поверх всех окон."""
        if self._compact_widget and self._compact_widget.isVisible():
            self._compact_widget.hide()
        else:
            if not self._compact_widget:
                self._compact_widget = CompactWidget(self)
            screen = QApplication.primaryScreen().availableGeometry()
            self._compact_widget.move(screen.right() - self._compact_widget.width() - 16,
                                      screen.top() + 48)
            self._compact_widget.show()
            self._compact_widget.raise_()
            self._compact_widget.activateWindow()

class CompactWidget(QWidget):
    """Компактный виджет — самостоятельное окно поверх всех окон.
    Показывает последний ответ AI, поле ввода, кнопки голоса/TTS.
    Живёт независимо; основное окно может быть скрыто."""

    def __init__(self, chat_window: "ChatWindow", parent=None):
        super().__init__(parent)
        self.cw = chat_window

        self.setWindowFlags(
            Qt.Window |
            Qt.WindowStaysOnTopHint |
            Qt.FramelessWindowHint |
            Qt.Tool  # не показывать в таскбаре
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(420)
        self._drag_pos = None
        self._build_ui()
        self._connect_signals()

    # ── UI ───────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Контейнер с закруглёнными углами
        self._container = QFrame()
        self._container.setObjectName("cw_container")
        self._container.setStyleSheet("""
            QFrame#cw_container {
                background: rgba(24, 24, 37, 235);
                border: 1px solid #45475a;
                border-radius: 14px;
            }
            QLineEdit {
                background: rgba(30, 30, 46, 200);
                color: #cdd6f4;
                border: 1px solid #45475a;
                border-radius: 8px;
                padding: 6px 10px;
                font-size: 10pt;
            }
            QPushButton {
                background: rgba(88, 91, 112, 180);
                color: #cdd6f4;
                border: 1px solid #45475a;
                border-radius: 7px;
                padding: 5px 10px;
                font-size: 10pt;
            }
            QPushButton:hover {
                background: rgba(137, 180, 250, 200);
                color: #1e1e2e;
            }
            QTextEdit {
                background: transparent;
                color: #89dceb;
                border: none;
                font-size: 10pt;
            }
        """)
        c_layout = QVBoxLayout(self._container)
        c_layout.setContentsMargins(12, 10, 12, 10)
        c_layout.setSpacing(7)

        # ─ Заголовок / drag-bar ─
        title_row = QHBoxLayout()
        self._title_lbl = QLabel("AI Chat")
        self._title_lbl.setStyleSheet(
            "color: #89b4fa; font-weight: bold; font-size: 10pt;")
        self._model_lbl = QLabel("")
        self._model_lbl.setStyleSheet(
            "color: #6c7086; font-size: 9pt;")

        open_btn = QPushButton("⛶")
        open_btn.setFixedSize(26, 26)
        open_btn.setToolTip("Открыть главное окно")
        open_btn.clicked.connect(self.cw._show_from_tray)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(26, 26)
        close_btn.clicked.connect(self.hide)

        title_row.addWidget(self._title_lbl)
        title_row.addWidget(self._model_lbl, 1)
        title_row.addWidget(open_btn)
        title_row.addWidget(close_btn)
        c_layout.addLayout(title_row)

        # ─ Последний ответ AI ─
        self._response_view = QTextEdit()
        self._response_view.setReadOnly(True)
        self._response_view.setFixedHeight(110)
        self._response_view.setPlaceholderText("Ответ AI появится здесь…")
        c_layout.addWidget(self._response_view)

        # ─ Индикатор «думает» ─
        self._busy_bar = QProgressBar()
        self._busy_bar.setRange(0, 0)
        self._busy_bar.setFixedHeight(3)
        self._busy_bar.setTextVisible(False)
        self._busy_bar.setVisible(False)
        self._busy_bar.setStyleSheet(
            "QProgressBar::chunk { background: #89b4fa; }")
        c_layout.addWidget(self._busy_bar)

        # ─ Поле ввода ─
        input_row = QHBoxLayout()
        self._input = QLineEdit()
        self._input.setPlaceholderText("Введите сообщение…")
        self._input.returnPressed.connect(self._send)

        self._mic_btn = QPushButton("🎤")
        self._mic_btn.setFixedSize(32, 32)
        self._mic_btn.setToolTip("Голосовой ввод")
        self._mic_btn.clicked.connect(self._toggle_mic)

        self._tts_btn = QPushButton("🔊")
        self._tts_btn.setFixedSize(32, 32)
        self._tts_btn.setToolTip("Озвучить / Стоп")
        self._tts_btn.setEnabled(False)
        self._tts_btn.clicked.connect(self.cw.toggle_tts)

        send_btn = QPushButton("➤")
        send_btn.setFixedSize(32, 32)
        send_btn.clicked.connect(self._send)

        input_row.addWidget(self._mic_btn)
        input_row.addWidget(self._input, 1)
        input_row.addWidget(self._tts_btn)
        input_row.addWidget(send_btn)
        c_layout.addLayout(input_row)

        root.addWidget(self._container)
        self.adjustSize()

    def _connect_signals(self):
        """Подключаемся к сигналам главного окна."""
        # Обновление ответа AI
        self.cw.ai_chat_history.textChanged.connect(self._sync_response)
        # Синхронизация модели в заголовке
        self.cw.model_combo.currentTextChanged.connect(self._sync_model)
        self._sync_model(self.cw.model_combo.currentText())

    def _sync_response(self):
        resp = self.cw.current_ai_response
        if resp:
            self._response_view.setPlainText(resp)
            sb = self._response_view.verticalScrollBar()
            sb.setValue(sb.maximum())
        self._tts_btn.setEnabled(bool(resp.strip()))
        # Синхронизируем busy-bar с главным окном
        self._busy_bar.setVisible(self.cw.thinking_indicator.isVisible())

    def _sync_model(self, name: str):
        self._model_lbl.setText(name[:30] + ("…" if len(name) > 30 else ""))

    # ── Действия ──────────────────────────────────────────────────────────

    def _send(self):
        text = self._input.text().strip()
        if not text:
            return
        self.cw.input_field.setText(text)
        self._input.clear()
        self.cw.send_message()
        self._busy_bar.setVisible(True)

    def _toggle_mic(self):
        if self.cw.is_listening:
            self.cw.stop_voice_input()
            self._mic_btn.setStyleSheet("")
        else:
            self.cw.start_voice_input()
            self._mic_btn.setStyleSheet("background: #ff4444; color: white;")
            # Вставить распознанный текст в виджет
            try:
                self.cw.voice_worker.speech_recognized.connect(self._on_speech)
            except Exception:
                pass

    def _on_speech(self, text: str):
        self._input.setText(text)
        self._mic_btn.setStyleSheet("")

    # ── Перетаскивание ────────────────────────────────────────────────────

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):
        if e.buttons() == Qt.LeftButton and self._drag_pos:
            self.move(self.pos() + e.globalPosition().toPoint() - self._drag_pos)
            self._drag_pos = e.globalPosition().toPoint()

    def mouseReleaseEvent(self, e):
        self._drag_pos = None


class ConversationModeWindow(QWidget):
    """Разговорный режим — автоматический цикл: слушать → отправить → озвучить.
    compact=True — компактное окно поверх всех окон."""

    def __init__(self, chat_window, compact=False, parent=None):
        super().__init__(parent)
        self.chat_window = chat_window
        self.compact = compact
        self._active = False
        self._cycle_after_tts = False

        flags = Qt.Window | Qt.WindowStaysOnTopHint
        if compact:
            flags |= Qt.FramelessWindowHint
            self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowFlags(flags)

        self.setWindowTitle("Разговорный режим" if not compact else "")
        if compact:
            self.setFixedSize(260, 90)
        else:
            self.setMinimumSize(420, 280)
            self.resize(440, 320)

        self._build_ui()

    # ------------------------------------------------------------------ UI --
    def _build_ui(self):
        layout = QVBoxLayout(self)

        if self.compact:
            layout.setContentsMargins(10, 8, 10, 8)
            layout.setSpacing(5)
            self.setStyleSheet("""
                QWidget {
                    background-color: rgba(30,30,46,220);
                    border-radius: 14px;
                    color: #cdd6f4;
                    font-family: 'Segoe UI', sans-serif;
                }
                QPushButton {
                    background: rgba(89,180,250,180);
                    border: none;
                    border-radius: 8px;
                    color: #1e1e2e;
                    font-weight: bold;
                    padding: 4px 10px;
                }
                QPushButton:hover { background: rgba(137,220,235,200); }
                QPushButton#stopBtn {
                    background: rgba(243,139,168,180);
                    color: #1e1e2e;
                }
            """)
        else:
            layout.setContentsMargins(15, 15, 15, 15)
            layout.setSpacing(8)

        # Status label
        self.status_label = QLabel("● Готов")
        self.status_label.setAlignment(Qt.AlignCenter)
        font = self.status_label.font()
        font.setPointSize(11 if self.compact else 13)
        font.setBold(True)
        self.status_label.setFont(font)
        layout.addWidget(self.status_label)

        # Last recognized text + transcript (hidden in compact)
        if not self.compact:
            self.text_label = QLabel("")
            self.text_label.setWordWrap(True)
            self.text_label.setAlignment(Qt.AlignCenter)
            self.text_label.setStyleSheet("color: #89dceb; font-size: 10pt; font-style: italic;")
            layout.addWidget(self.text_label)

            self.transcript = QTextEdit()
            self.transcript.setReadOnly(True)
            self.transcript.setMaximumHeight(120)
            self.transcript.setPlaceholderText("Здесь появится стенограмма диалога...")
            self.transcript.setStyleSheet(
                "background: rgba(30,30,46,180); color: #cdd6f4; "
                "border: 1px solid #45475a; border-radius: 6px; font-size: 9pt;"
            )
            layout.addWidget(self.transcript)

        # Buttons row
        btn_row = QHBoxLayout()
        self.start_btn = QPushButton("▶  Старт")
        self.start_btn.clicked.connect(self.start_cycle)

        self.stop_btn = QPushButton("■  Стоп")
        self.stop_btn.setObjectName("stopBtn")
        self.stop_btn.clicked.connect(self.stop_cycle)
        self.stop_btn.setEnabled(False)

        close_btn = QPushButton("✕")
        close_btn.setFixedWidth(32)
        close_btn.clicked.connect(self.close)

        btn_row.addWidget(self.start_btn)
        btn_row.addWidget(self.stop_btn)
        if not self.compact:
            clear_btn = QPushButton("🗑")
            clear_btn.setFixedWidth(36)
            clear_btn.setToolTip("Очистить стенограмму")
            clear_btn.clicked.connect(self._clear_transcript)
            btn_row.addWidget(clear_btn)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

        # Drag support for compact mode
        self._drag_pos = None

    # ------------------------------------------------------ drag (compact) --
    def mousePressEvent(self, event):
        if self.compact and event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self.compact and event.buttons() == Qt.LeftButton and self._drag_pos:
            self.move(self.pos() + event.globalPosition().toPoint() - self._drag_pos)
            self._drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    # ----------------------------------------------------------- cycle logic --
    def start_cycle(self):
        self._active = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self._listen()

    def stop_cycle(self):
        self._active = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self._set_status("■ Остановлен", "#f38ba8")
        # Stop TTS if playing
        cw = self.chat_window
        if cw.is_speaking and cw.tts_worker:
            cw.tts_worker.stop()

    def _listen(self):
        if not self._active:
            return
        self._set_status("🎤 Слушаю…", "#a6e3a1")
        cw = self.chat_window
        cw.voice_worker = VoiceWorker(mode="recognize")
        cw.voice_worker.speech_recognized.connect(self._on_recognized)
        cw.voice_worker.error_occurred.connect(self._on_listen_error)
        cw.voice_worker.start()

    def _on_recognized(self, text):
        if not self._active:
            return
        if not self.compact:
            self.text_label.setText(f"«{text}»")
            if hasattr(self, "transcript"):
                self.transcript.append(f"<span style='color:#a6e3a1'><b>Вы:</b> {text}</span>")
        self._set_status("⌛ Обрабатываю…", "#89b4fa")
        cw = self.chat_window
        # hook into ai finished to start TTS then listen again
        self._cycle_after_tts = True
        cw.input_field.setText(text)
        # connect once to on_ai_finished to speak & re-listen
        try:
            cw.ollama_worker.finished_signal.disconnect(self._on_ai_done)
        except Exception:
            pass
        cw.send_message()
        # We need to hook after next AI response
        QTimer.singleShot(200, self._hook_ai_worker)

    def _hook_ai_worker(self):
        cw = self.chat_window
        if cw.ollama_worker:
            try:
                cw.ollama_worker.finished_signal.disconnect(self._on_ai_done)
            except Exception:
                pass
            cw.ollama_worker.finished_signal.connect(self._on_ai_done)

    def _on_ai_done(self):
        if not self._active:
            return
        self._set_status("🔊 Озвучиваю…", "#f9e2af")
        cw = self.chat_window
        if cw.current_ai_response.strip() and not self.compact and hasattr(self, "transcript"):
            snippet = cw.current_ai_response.strip()[:120]
            if len(cw.current_ai_response.strip()) > 120:
                snippet += "…"
            self.transcript.append(f"<span style='color:#89dceb'><b>AI:</b> {snippet}</span>")
        if cw.current_ai_response.strip():
            cw.tts_worker = VoiceWorker(mode="synthesize", text=cw.current_ai_response)
            cw.tts_worker.voice_playing.connect(self._on_tts_done)
            cw.tts_worker.error_occurred.connect(lambda e: self._listen())
            cw.is_speaking = True
            cw.tts_worker.start()
        else:
            self._listen()

    def _on_tts_done(self, playing):
        if not playing:
            self.chat_window.is_speaking = False
            if self._active:
                QTimer.singleShot(300, self._listen)

    def _on_listen_error(self, err):
        if not self._active:
            return
        self._set_status(f"⚠ {err[:35]}", "#f38ba8")
        QTimer.singleShot(1500, self._listen)

    def _clear_transcript(self):
        if hasattr(self, "transcript"):
            self.transcript.clear()

    def _set_status(self, text, color="#cdd6f4"):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {color}; font-weight: bold;")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Chat")
    app.setApplicationVersion("2.0")
    # Не завершать приложение при закрытии всех окон — живём в трее
    app.setQuitOnLastWindowClosed(False)

    window = ChatWindow()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()