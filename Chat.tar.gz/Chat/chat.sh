#!/bin/bash

# Имя вашего Python-файла
PYTHON_SCRIPT="chat.py"

# Проверяем, существует ли файл скрипта
if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo "Ошибка: Файл скрипта '$PYTHON_SCRIPT' не найден."
    echo "Убедитесь, что скрипт находится в той же директории, откуда вы запускаете этот bash-скрипт,"
    echo "или укажите полный путь к файлу."
    exit 1
fi

# Проверяем наличие python3
if ! command -v python3 &> /dev/null
then
    echo "Ошибка: python3 не установлен. Пожалуйста, установите python3."
    exit 1
fi

# Запускаем Python-скрипт
echo "Запуск скрипта '$PYTHON_SCRIPT'..."
python3 "$PYTHON_SCRIPT"

# Проверяем код завершения Python-скрипта
if [ $? -eq 0 ]; then
    echo "Скрипт '$PYTHON_SCRIPT' успешно завершил работу."
else
    echo "Скрипт '$PYTHON_SCRIPT' завершился с ошибками."
fi
